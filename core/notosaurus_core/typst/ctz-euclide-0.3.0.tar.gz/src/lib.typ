// ctz-euclide/src/lib.typ
// Main entry point for ctz-euclide Typst package
//
// A port of the LaTeX tkz-euclide package for Euclidean geometry
// Uses cetz as the drawing backend

#import "@preview/cetz:0.5.2" as cetz

// Internal modules are bound with a leading underscore so that a user-side
// `#import "@preview/ctz-euclide:X.Y.Z": *` does not leak generic names like
// `util`, `draw` or `circle` into the document. `cetz` IS exported on
// purpose: `import cetz.draw: *` inside ctz-canvas is the documented pattern.
#import "util.typ" as _util
#import "intersection.typ" as _intersection
#import "triangle.typ" as _triangle
#import "transform.typ" as _transform
#import "draw.typ" as _draw
#import "drawing.typ" as _drawing
#import "circle.typ" as _circle
#import "conic.typ" as _conic

/// Package version (read from typst.toml so it can never drift)
#let _version = toml("../typst.toml").package.version.split(".").map(int)

// Re-export cetz canvas for convenience
#let _canvas = cetz.canvas

/// Internal key for storing points in shared-state
#let _points-key = "ctz-points"
/// Internal key for storing named lines in shared-state
#let _lines-key = "ctz-lines"
/// Internal key for storing named circles in shared-state
#let _circles-key = "ctz-circles"
/// Internal key for storing named polygons in shared-state
#let _polygons-key = "ctz-polygons"
/// Internal key for storing named conics in shared-state
#let _conics-key = "ctz-conics"

/// Get all stored points from context
#let _get-points(ctx) = {
  ctx.shared-state.at(_points-key, default: (:))
}

/// Store points in context
#let _set-points(ctx, points) = {
  ctx.shared-state.insert(_points-key, points)
  ctx
}

/// Get all stored lines from context
#let _get-lines(ctx) = {
  ctx.shared-state.at(_lines-key, default: (:))
}

/// Store lines in context
#let _set-lines(ctx, lines) = {
  ctx.shared-state.insert(_lines-key, lines)
  ctx
}

/// Get all stored circles from context
#let _get-circles(ctx) = {
  ctx.shared-state.at(_circles-key, default: (:))
}

/// Store circles in context
#let _set-circles(ctx, circles) = {
  ctx.shared-state.insert(_circles-key, circles)
  ctx
}

/// Get all stored polygons from context
#let _get-polygons(ctx) = {
  ctx.shared-state.at(_polygons-key, default: (:))
}

/// Store polygons in context
#let _set-polygons(ctx, polygons) = {
  ctx.shared-state.insert(_polygons-key, polygons)
  ctx
}

/// Get all stored conics from context
#let _get-conics(ctx) = {
  ctx.shared-state.at(_conics-key, default: (:))
}

/// Store conics in context
#let _set-conics(ctx, conics) = {
  ctx.shared-state.insert(_conics-key, conics)
  ctx
}

/// Get the object type for a given name
/// Returns "point", "line", "circle", "polygon", or none
#let _get-object-type(ctx, name) = {
  let found-types = ()

  if name in _get-points(ctx) {
    found-types.push("point")
  }
  if name in _get-lines(ctx) {
    found-types.push("line")
  }
  if name in _get-circles(ctx) {
    found-types.push("circle")
  }
  if name in _get-polygons(ctx) {
    found-types.push("polygon")
  }
  if name in _get-conics(ctx) {
    found-types.push("conic")
  }

  if found-types.len() == 0 {
    return none
  } else if found-types.len() > 1 {
    panic("Ambiguous object '" + name + "' exists as both " + found-types.at(0) + " and " + found-types.at(1) + ". Use unique names.")
  } else {
    return found-types.at(0)
  }
}

/// Custom coordinate resolver - accepts both "A" and "ctz:A" syntax
#let _ctz-coordinate-resolver(ctx, c) = {
  if type(c) == str {
    let points = _get-points(ctx)
    // Try with "ctz:" prefix first
    if c.starts-with("ctz:") {
      let name = c.slice(4)
      if name in points {
        return points.at(name)
      }
    }
    // Try direct name lookup (e.g., "A" instead of "ctz:A")
    if c in points {
      return points.at(c)
    }
  }
  c
}

/// Initialize ctz-euclide in a cetz canvas
/// Must be called at the start of canvas body
#let _init() = {
  cetz.draw.set-ctx(ctx => {
    // Initialize shared state for point storage
    if _points-key not in ctx.shared-state {
      ctx.shared-state.insert(_points-key, (:))
    }
    if _lines-key not in ctx.shared-state {
      ctx.shared-state.insert(_lines-key, (:))
    }
    if _circles-key not in ctx.shared-state {
      ctx.shared-state.insert(_circles-key, (:))
    }
    if _polygons-key not in ctx.shared-state {
      ctx.shared-state.insert(_polygons-key, (:))
    }
    if _conics-key not in ctx.shared-state {
      ctx.shared-state.insert(_conics-key, (:))
    }
    // Register coordinate resolver if not already done
    if type(ctx.resolve-coordinate) != array {
      ctx.resolve-coordinate = ()
    }
    if _ctz-coordinate-resolver not in ctx.resolve-coordinate {
      ctx.resolve-coordinate.push(_ctz-coordinate-resolver)
    }
    ctx
  })
}

/// Resolve a point reference to coordinates (internal helper)
#let _resolve-point(ctx, p) = {
  if type(p) == str {
    // Check if it's a ctz point name
    let points = _get-points(ctx)
    if p in points {
      return points.at(p)
    }
    // Try to strip "ctz:" prefix
    if p.starts-with("ctz:") {
      let name = p.slice(4)
      if name in points {
        return points.at(name)
      }
    }
    // Fall back to cetz coordinate resolution
    let (_, _pt) = cetz.coordinate.resolve(ctx, p)
    return _pt
  } else if type(p) == array {
    if p.len() >= 2 and p.len() <= 3 and p.all(x => type(x) in (int, float)) {
      return if p.len() == 2 { (p.at(0), p.at(1), 0) } else { p }
    }
    let (_, _pt) = cetz.coordinate.resolve(ctx, p)
    return _pt
  } else if type(p) == dictionary {
    let (_, _pt) = cetz.coordinate.resolve(ctx, p)
    return _pt
  }
  panic("Cannot resolve point: " + repr(p))
}

/// Resolve a vector (array of numbers or pair of points)
#let _resolve-vector(ctx, vector) = {
  if type(vector) == array and vector.len() == 2 and vector.all(v => type(v) in (int, float, length)) {
    let resolve-num(v) = if type(v) == length { v / 1cm } else { v }
    return (resolve-num(vector.at(0)), resolve-num(vector.at(1)), 0)
  }
  if type(vector) == array and vector.len() == 2 {
    let v1 = _resolve-point(ctx, vector.at(0))
    let v2 = _resolve-point(ctx, vector.at(1))
    return (v2.at(0) - v1.at(0), v2.at(1) - v1.at(1), 0)
  }
  panic("Cannot resolve vector: " + repr(vector))
}

/// Helper to convert point name to ctz: coordinate (or pass through raw coordinates)
#let _pt(name) = {
  if type(name) == str {
    "ctz:" + name
  } else {
    // Raw coordinate tuple - pass through
    name
  }
}

/// Define multiple points at once
#let _pts(..points) = {
  let pairs = if points.named() != (:) {
    points.named().pairs()
  } else {
    let pos = points.pos()
    assert(calc.rem(pos.len(), 2) == 0,
      message: "ctz-pts requires name-coordinate pairs")
    range(0, pos.len(), step: 2).map(i => (pos.at(i), pos.at(i + 1)))
  }

  (ctx => {
    for (name, coord) in pairs {
      let _pt = if type(coord) == array and coord.len() >= 2 and coord.len() <= 3 and coord.all(x => type(x) in (int, float, length)) {
        let resolve-num(v) = if type(v) == length { v / 1cm } else { v }
        let x = resolve-num(coord.at(0))
        let y = resolve-num(coord.at(1))
        let z = if coord.len() > 2 { resolve-num(coord.at(2)) } else { 0 }
        (x, y, z)
      } else {
        let (ctx2, resolved) = cetz.coordinate.resolve(ctx, coord)
        ctx = ctx2
        resolved
      }

      let stored = _get-points(ctx)
      stored.insert(name, _pt)
      ctx = _set-points(ctx, stored)
    }
    (ctx: ctx)
  },)
}

/// Parse line specification (name or pair of points)
#let _parse-line(ctx, line-spec) = {
  if type(line-spec) == str {
    let lines = _get-lines(ctx)
    if line-spec in lines {
      return lines.at(line-spec)
    }
    panic("Line '" + line-spec + "' not found")
  } else if type(line-spec) == array and line-spec.len() == 2 {
    let p1 = _resolve-point(ctx, line-spec.at(0))
    let p2 = _resolve-point(ctx, line-spec.at(1))
    return (p1, p2)
  }
  panic("Invalid line specification: " + repr(line-spec))
}

/// Line-line intersection
#let _ll(name, line1, line2, ray: true) = {
  (ctx => {
    let (p1, p2) = _parse-line(ctx, line1)
    let (p3, p4) = _parse-line(ctx, line2)

    let result = _intersection.line-line-raw(p1, p2, p3, p4, ray: ray)
    assert(result != none, message: "Lines are parallel, no intersection found")

    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)

    (ctx: ctx)
  },)
}

/// Parse circle specification
#let _parse-circle(ctx, circle-spec) = {
  if type(circle-spec) == str {
    let circles = _get-circles(ctx)
    if circle-spec in circles {
      let c = circles.at(circle-spec)
      return (c.center, c.radius)
    }
    panic("Circle '" + circle-spec + "' not found")
  } else if type(circle-spec) == dictionary {
    let center = _resolve-point(ctx, circle-spec.center)
    let radius = if "radius" in circle-spec {
      if type(circle-spec.radius) == length { circle-spec.radius / 1cm } else { circle-spec.radius }
    } else if "through" in circle-spec {
      let _pt = _resolve-point(ctx, circle-spec.through)
      _util.dist(center, _pt)
    } else {
      panic("Circle needs radius or through point")
    }
    (center, radius)
  } else if type(circle-spec) == array and circle-spec.len() == 2 {
    let center = _resolve-point(ctx, circle-spec.at(0))
    let _pt = _resolve-point(ctx, circle-spec.at(1))
    (center, _util.dist(center, _pt))
  } else {
    panic("Invalid circle specification: " + repr(circle-spec))
  }
}

/// Line-circle intersection
#let _lc(result-names, line, circle-spec, near: none) = {
  (ctx => {
    let (la, lb) = _parse-line(ctx, line)
    let (center, radius) = _parse-circle(ctx, circle-spec)

    let results = _intersection.line-circle-raw(la, lb, center, radius)

    if near != none and results.len() > 1 {
      let near-pt = _resolve-point(ctx, near)
      results = results.sorted(key: _pt => _util.dist-sq(near-pt, _pt))
    }

    let names = if type(result-names) == str { (result-names,) } else { result-names }
    let points = _get-points(ctx)
    for (i, _pt-name) in names.enumerate() {
      if i < results.len() {
        points.insert(_pt-name, results.at(i))
      }
    }
    ctx = _set-points(ctx, points)

    (ctx: ctx)
  },)
}

/// Circle-circle intersection
#let _cc(result-names, circle1, circle2) = {
  (ctx => {
    let (c0, r0) = _parse-circle(ctx, circle1)
    let (c1, r1) = _parse-circle(ctx, circle2)

    let results = _intersection.circle-circle-raw(c0, r0, c1, r1)

    let names = if type(result-names) == str { (result-names,) } else { result-names }
    let points = _get-points(ctx)
    for (i, _pt-name) in names.enumerate() {
      if i < results.len() {
        points.insert(_pt-name, results.at(i))
      }
    }
    ctx = _set-points(ctx, points)

    (ctx: ctx)
  },)
}

/// Define a named line from two points
#let _def-line-name(name, a, b) = {
  (ctx => {
    let p1 = _resolve-point(ctx, a)
    let p2 = _resolve-point(ctx, b)
    let lines = _get-lines(ctx)
    lines.insert(name, (p1, p2))
    ctx = _set-lines(ctx, lines)
    (ctx: ctx)
  },)
}

/// Define a named circle by center and radius/through point
#let _def-circle(name, center, radius: auto, through: none) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let r = if radius != auto {
      if type(radius) == length { radius / 1cm } else { radius }
    } else if through != none {
      let p = _resolve-point(ctx, through)
      _util.dist(c, p)
    } else {
      panic("Circle needs radius or through point")
    }

    let circles = _get-circles(ctx)
    circles.insert(name, (center: c, radius: r))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named circle by diameter endpoints
#let _def-circle-diameter(name, a, b) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let (center, radius) = _circle.circle-diameter-raw(pa, pb)

    let circles = _get-circles(ctx)
    circles.insert(name, (center: center, radius: radius))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named circumcircle of triangle
#let _def-circumcircle(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (center, radius) = _circle.circle-circum-raw(pa, pb, pc)

    let circles = _get-circles(ctx)
    circles.insert(name, (center: center, radius: radius))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named incircle of triangle
#let _def-incircle(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (center, radius) = _circle.circle-in-raw(pa, pb, pc)

    let circles = _get-circles(ctx)
    circles.insert(name, (center: center, radius: radius))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named excircle of triangle opposite to vertex
#let _def-excircle(name, a, b, c, vertex: "a") = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (center, radius) = _circle.circle-ex-raw(pa, pb, pc, vertex: vertex)

    let circles = _get-circles(ctx)
    circles.insert(name, (center: center, radius: radius))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named nine-point (Euler) circle of triangle
#let _def-euler-circle(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (center, radius) = _circle.circle-euler-raw(pa, pb, pc)

    let circles = _get-circles(ctx)
    circles.insert(name, (center: center, radius: radius))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named Spieker circle (incircle of medial triangle)
#let _def-spieker-circle(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (center, radius) = _circle.circle-spieker-raw(pa, pb, pc)

    let circles = _get-circles(ctx)
    circles.insert(name, (center: center, radius: radius))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named Apollonius circle
#let _def-apollonius-circle(name, a, b, k) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let result = _circle.apollonius-circle-raw(pa, pb, k)

    if result == none {
      panic("Apollonius circle with k=1 is a line (perpendicular bisector), not a circle")
    }

    let (center, radius) = result
    let circles = _get-circles(ctx)
    circles.insert(name, (center: center, radius: radius))
    ctx = _set-circles(ctx, circles)
    (ctx: ctx)
  },)
}

/// Define a named ellipse by center and radii
#let _def-ellipse(name, center, rx, ry, angle: 0deg) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let ang = _util.to-angle(angle)

    let conics = _get-conics(ctx)
    conics.insert(name, (type: "ellipse", center: c, rx: rx-num, ry: ry-num, angle: ang))
    ctx = _set-conics(ctx, conics)
    (ctx: ctx)
  },)
}

/// Define a named parabola by focus and directrix
#let _def-parabola(name, focus, directrix, extent: auto, steps: 120) = {
  (ctx => {
    let f = _resolve-point(ctx, focus)
    let (a, b) = _parse-line(ctx, directrix)
    let ext = if type(extent) == length { extent / 1cm } else { extent }

    let conics = _get-conics(ctx)
    conics.insert(name, (type: "parabola", focus: f, directrix: (a, b), extent: ext, steps: steps))
    ctx = _set-conics(ctx, conics)
    (ctx: ctx)
  },)
}

/// Define a named projectile trajectory (parabola)
#let _def-projectile(
  name,
  origin,
  velocity,
  gravity: 9.81,
  t-max: auto,
  steps: 80,
  y-floor: none,
  vectors: false,
  vector-count: 5,
  vector-scale: 0.12,
) = {
  (ctx => {
    let o = _resolve-point(ctx, origin)
    let v = _resolve-vector(ctx, velocity)
    let y-floor-num = if y-floor != none and type(y-floor) == length { y-floor / 1cm } else { y-floor }

    let conics = _get-conics(ctx)
    conics.insert(name, (
      type: "projectile",
      origin: o,
      velocity: v,
      gravity: gravity,
      t-max: t-max,
      steps: steps,
      y-floor: y-floor-num,
      vectors: vectors,
      vector-count: vector-count,
      vector-scale: vector-scale,
    ))
    ctx = _set-conics(ctx, conics)
    (ctx: ctx)
  },)
}

/// Define a parabola by focus, parameter p (focus-vertex distance), and angle
#let _def-parabola-focus(name, focus, p, angle: 0deg, extent: auto, steps: 120) = {
  (ctx => {
    let f = _resolve-point(ctx, focus)
    let p-num = if type(p) == length { p / 1cm } else { p }
    let ext = if extent == auto { auto } else if type(extent) == length { extent / 1cm } else { extent }
    let (d1, d2, _vertex) = _conic.parabola-directrix-raw(f, p-num, angle: angle)

    let conics = _get-conics(ctx)
    conics.insert(name, (type: "parabola", focus: f, directrix: (d1, d2), extent: ext, steps: steps))
    ctx = _set-conics(ctx, conics)
    (ctx: ctx)
  },)
}

/// Define the two foci of an ellipse as named points
#let _def-ellipse-foci(name1, name2, center, rx, ry, angle: 0deg) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let (f1, f2) = _conic.ellipse-foci-raw(c, rx-num, ry-num, angle: angle)

    let points = _get-points(ctx)
    points.insert(name1, f1)
    points.insert(name2, f2)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define tangent line at parameter t on an ellipse
#let _def-ellipse-tangent(name, center, rx, ry, t, angle: 0deg, length: auto) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let len = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    let (p1, p2, _pt) = _conic.ellipse-tangent-raw(c, rx-num, ry-num, angle: angle, t: t, length: len)

    let lines = _get-lines(ctx)
    lines.insert(name, (p1, p2))
    ctx = _set-lines(ctx, lines)
    (ctx: ctx)
  },)
}

/// Define tangent lines from external point to ellipse
#let _def-ellipse-tangents-from(name1, name2, center, rx, ry, external, angle: 0deg, length: auto) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let ext = _resolve-point(ctx, external)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let len = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    let tangents = _conic.ellipse-tangents-from-point-raw(c, rx-num, ry-num, angle: angle, ext, length: len)

    let lines = _get-lines(ctx)
    if tangents.len() >= 1 {
      let (p1, p2, _pt) = tangents.at(0)
      lines.insert(name1, (p1, p2))
    }
    if tangents.len() >= 2 {
      let (p1, p2, _pt) = tangents.at(1)
      lines.insert(name2, (p1, p2))
    }
    ctx = _set-lines(ctx, lines)
    (ctx: ctx)
  },)
}

/// Define tangent line at parameter t on a parabola
#let _def-parabola-tangent(name, focus, directrix, t, length: auto) = {
  (ctx => {
    let f = _resolve-point(ctx, focus)
    let (da, db) = _parse-line(ctx, directrix)
    let len = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    let result = _conic.parabola-tangent-raw(f, da, db, t, length: len)

    if result != none {
      let (p1, p2, _pt) = result
      let lines = _get-lines(ctx)
      lines.insert(name, (p1, p2))
      ctx = _set-lines(ctx, lines)
    }
    (ctx: ctx)
  },)
}

/// Define tangent lines from external point to parabola
#let _def-parabola-tangents-from(name1, name2, focus, directrix, external, length: auto) = {
  (ctx => {
    let f = _resolve-point(ctx, focus)
    let (da, db) = _parse-line(ctx, directrix)
    let ext = _resolve-point(ctx, external)
    let len = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    let tangents = _conic.parabola-tangents-from-point-raw(f, da, db, ext, length: len)

    let lines = _get-lines(ctx)
    if tangents.len() >= 1 {
      let (p1, p2, _pt) = tangents.at(0)
      lines.insert(name1, (p1, p2))
    }
    if tangents.len() >= 2 {
      let (p1, p2, _pt) = tangents.at(1)
      lines.insert(name2, (p1, p2))
    }
    ctx = _set-lines(ctx, lines)
    (ctx: ctx)
  },)
}

/// Define a named polygon from ordered points
#let _def-polygon(name, ..points) = {
  let pts = points.pos()
  if pts.len() < 3 {
    panic("Polygon needs at least three points")
  }
  (ctx => {
    let polygons = _get-polygons(ctx)
    polygons.insert(name, pts)
    ctx = _set-polygons(ctx, polygons)
    (ctx: ctx)
  },)
}

/// Triangle centroid
#let _centroid(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.centroid-raw(pa, pb, pc)

    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Triangle circumcenter
#let _circumcenter(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.circumcenter-raw(pa, pb, pc)

    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Triangle incenter
#let _incenter(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.incenter-raw(pa, pb, pc)

    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Triangle orthocenter
#let _orthocenter(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.orthocenter-raw(pa, pb, pc)

    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

// =============================================================================
// ADDITIONAL TRIANGLE CENTERS
// =============================================================================

/// Nine-point (Euler) circle center
#let _euler(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.euler-center-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Lemoine point (symmedian point)
#let _lemoine(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.lemoine-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Nagel point
#let _nagel(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.nagel-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Gergonne point
#let _gergonne(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.gergonne-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Spieker center
#let _spieker(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.spieker-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Feuerbach point
#let _feuerbach(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.feuerbach-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Mittenpunkt
#let _mittenpunkt(name, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.mittenpunkt-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Excenter (opposite to specified vertex)
#let _excenter(name, a, b, c, vertex: "a") = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let center = _triangle.excenter-raw(pa, pb, pc, vertex: vertex)
    let points = _get-points(ctx)
    points.insert(name, center)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

// =============================================================================
// SPECIAL TRIANGLES
// =============================================================================

/// Define medial triangle vertices
#let _medial(name-a, name-b, name-c, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (ma, mb, mc) = _triangle.medial-triangle-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name-a, ma)
    points.insert(name-b, mb)
    points.insert(name-c, mc)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define orthic triangle vertices
#let _orthic(name-a, name-b, name-c, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (ha, hb, hc) = _triangle.orthic-triangle-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name-a, ha)
    points.insert(name-b, hb)
    points.insert(name-c, hc)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define intouch triangle vertices
#let _intouch(name-a, name-b, name-c, a, b, c) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let (ta, tb, tc) = _triangle.intouch-triangle-raw(pa, pb, pc)
    let points = _get-points(ctx)
    points.insert(name-a, ta)
    points.insert(name-b, tb)
    points.insert(name-c, tc)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

// =============================================================================
// POINT CONSTRUCTIONS
// =============================================================================

/// Define midpoint of segment AB
#let _midpoint(name, a, b) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let mid = _util.midpoint(pa, pb)
    let points = _get-points(ctx)
    points.insert(name, mid)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define equilateral triangle third point
#let _equilateral(name, a, b) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _util.equilateral-point(pa, pb)
    let points = _get-points(ctx)
    points.insert(name, pc)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define square third and fourth points
#let _square(name-c, name-d, a, b) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let (pc, pd) = _util.square-points(pa, pb)
    let points = _get-points(ctx)
    points.insert(name-c, pc)
    points.insert(name-d, pd)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define golden ratio point
#let _golden(name, a, b, inside: true) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _util.golden-ratio-point(pa, pb, inside: inside)
    let points = _get-points(ctx)
    points.insert(name, pc)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define Thales triangle (right triangle inscribed in circle)
/// Creates three points where the right angle is at name-c
#let _thales-triangle(name-a, name-b, name-c, center, radius, base-angle: 0, orientation: "left") = {
  (ctx => {
    // Resolve center
    let c = _resolve-point(ctx, center)
    let r = if type(radius) == length {
      radius / 1cm
    } else {
      radius
    }

    // Calculate angles for three vertices
    let angle-a = base-angle
    let angle-b = base-angle + 180
    let angle-c = if orientation == "left" {
      base-angle + 90
    } else {
      base-angle - 90
    }

    // Calculate point positions using point-on-circle from _transform.typ
    let pa = _transform.point-on-circle-raw(c, r, angle-a)
    let pb = _transform.point-on-circle-raw(c, r, angle-b)
    let pc = _transform.point-on-circle-raw(c, r, angle-c)

    // Store all three points
    let points = _get-points(ctx)
    points.insert(name-a, pa)
    points.insert(name-b, pb)
    points.insert(name-c, pc)
    ctx = _set-points(ctx, points)

    (ctx: ctx)
  },)
}

/// Define barycentric point
#let _barycentric(name, a, b, c, wa, wb, wc) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let pc = _resolve-point(ctx, c)
    let result = _util.barycentric-point(pa, pb, pc, wa, wb, wc)
    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define point on circle at angle
#let _point-on-circle(name, center, radius, angle-deg) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let r = if type(radius) == length { radius / 1cm } else { radius }
    let result = _util.point-on-circle(c, r, angle-deg)
    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define regular polygon vertices
#let _regular-polygon(..args) = {
  let pos = args.pos()
  if pos.len() < 3 {
    panic("Regular polygon needs names, center, and first vertex")
  }
  let name = none
  let names = none
  let center = none
  let first-vertex = none
  if type(pos.at(0)) == str {
    if pos.len() < 4 {
      panic("Regular polygon needs name, names, center, and first vertex")
    }
    name = pos.at(0)
    names = pos.at(1)
    center = pos.at(2)
    first-vertex = pos.at(3)
  } else {
    names = pos.at(0)
    center = pos.at(1)
    first-vertex = pos.at(2)
  }
  (ctx => {
    let c = _resolve-point(ctx, center)
    let fv = _resolve-point(ctx, first-vertex)
    let n = names.len()
    let vertices = _util.regular-polygon-vertices(c, fv, n)
    let points = _get-points(ctx)
    for (i, vname) in names.enumerate() {
      points.insert(vname, vertices.at(i))
    }
    ctx = _set-points(ctx, points)
    if name != none {
      let polygons = _get-polygons(ctx)
      polygons.insert(name, names)
      ctx = _set-polygons(ctx, polygons)
    }
    (ctx: ctx)
  },)
}

/// Define linear combination point: P = A + k*(B-A)
#let _linear(name, a, b, k) = {
  (ctx => {
    let pa = _resolve-point(ctx, a)
    let pb = _resolve-point(ctx, b)
    let result = _util.linear-point(pa, pb, k)
    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define central symmetry point
#let _symmetry(name, source, center) = {
  (ctx => {
    let p = _resolve-point(ctx, source)
    let c = _resolve-point(ctx, center)
    let result = _util.central-symmetry(p, c)
    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define inversion of point/object through a circle (polymorphic)
#let _inversion(name, source, center, radius) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let r = if type(radius) == length { radius / 1cm } else { radius }

    // Detect source object type
    let obj-type = _get-object-type(ctx, source)

    if obj-type == none {
      // Treat as a point
      let p = _resolve-point(ctx, source)
      let result = _util.circle-inversion(p, c, r)
      let points = _get-points(ctx)
      points.insert(name, result)
      ctx = _set-points(ctx, points)
    } else if obj-type == "point" {
      let p = _resolve-point(ctx, source)
      let result = _util.circle-inversion(p, c, r)
      let points = _get-points(ctx)
      points.insert(name, result)
      ctx = _set-points(ctx, points)
    } else if obj-type == "line" {
      let lines = _get-lines(ctx)
      let (p1, p2) = lines.at(source)
      let foot = _util.project-point-on-line(c, p1, p2)
      let dist-to-line = _util.dist(c, foot)

      if _util.approx-zero(dist-to-line) {
        // Line through inversion center -> invariant
        lines.insert(name, (p1, p2))
        ctx = _set-lines(ctx, lines)
      } else {
        // Inversion of a line not through center is a circle through center
        let foot-inv = _util.circle-inversion(foot, c, r)
        let mid = _util.midpoint(c, foot-inv)
        let rad = _util.dist(c, foot-inv) / 2
        let circles = _get-circles(ctx)
        circles.insert(name, (center: mid, radius: rad))
        ctx = _set-circles(ctx, circles)
      }
    } else if obj-type == "circle" {
      let circles = _get-circles(ctx)
      let circ = circles.at(source)
      let d = _util.dist(c, circ.center)

      if _util.approx-eq(d, circ.radius, epsilon: _util.eps) {
        // Circle through inversion center -> line
        let dx = circ.center.at(0) - c.at(0)
        let dy = circ.center.at(1) - c.at(1)
        let far = (
          c.at(0) + 2 * dx,
          c.at(1) + 2 * dy,
          circ.center.at(2, default: 0),
        )
        let p0 = _util.circle-inversion(far, c, r)
        let p1 = (p0.at(0) - dy, p0.at(1) + dx, p0.at(2, default: 0))
        let p2 = (p0.at(0) + dy, p0.at(1) - dx, p0.at(2, default: 0))
        let lines = _get-lines(ctx)
        lines.insert(name, (p1, p2))
        ctx = _set-lines(ctx, lines)
      } else {
        // Circle not through center -> circle
        let denom = d * d - circ.radius * circ.radius
        let factor = (r * r) / denom
        let new-center = (
          c.at(0) + factor * (circ.center.at(0) - c.at(0)),
          c.at(1) + factor * (circ.center.at(1) - c.at(1)),
          circ.center.at(2, default: 0),
        )
        let new-radius = calc.abs(factor) * circ.radius
        circles.insert(name, (center: new-center, radius: new-radius))
        ctx = _set-circles(ctx, circles)
      }
    } else if obj-type == "polygon" {
      let polygons = _get-polygons(ctx)
      let vertex-names = polygons.at(source)
      let points = _get-points(ctx)

      for vname in vertex-names {
        if vname not in points {
          panic("Cannot invert polygon '" + source + "': vertex point '" + vname + "' not found. All vertex points must be explicitly defined.")
        }
        let pt = points.at(vname)
        let inv-pt = _util.circle-inversion(pt, c, r)
        points.insert(vname, inv-pt)
      }
      ctx = _set-points(ctx, points)
      polygons.insert(name, vertex-names)
      ctx = _set-polygons(ctx, polygons)
    }

    (ctx: ctx)
  },)
}

// =============================================================================
// TANGENT DEFINITIONS
// =============================================================================

/// Define tangent points from external point to circle
#let _tangent-from(name1, name2, external-point, center, radius) = {
  (ctx => {
    let p = _resolve-point(ctx, external-point)
    let c = _resolve-point(ctx, center)
    let r = if type(radius) == length { radius / 1cm } else { radius }
    let tangents = _circle.tangent-from-point-raw(p, c, r)
    let points = _get-points(ctx)
    if tangents.len() >= 1 { points.insert(name1, tangents.at(0)) }
    if tangents.len() >= 2 { points.insert(name2, tangents.at(1)) }
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define tangent line at point on circle
#let _tangent-at(name1, name2, point-on-circle, center) = {
  (ctx => {
    let p = _resolve-point(ctx, point-on-circle)
    let c = _resolve-point(ctx, center)
    let (t1, t2) = _circle.tangent-at-point-raw(p, c)
    let points = _get-points(ctx)
    points.insert(name1, t1)
    points.insert(name2, t2)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define radical axis of two circles
#let _radical-axis(name1, name2, center1, radius1, center2, radius2) = {
  (ctx => {
    let c1 = _resolve-point(ctx, center1)
    let c2 = _resolve-point(ctx, center2)
    let r1 = if type(radius1) == length { radius1 / 1cm } else { radius1 }
    let r2 = if type(radius2) == length { radius2 / 1cm } else { radius2 }
    let result = _circle.radical-axis-raw(c1, r1, c2, r2)
    if result != none {
      let (p1, p2) = result
      let points = _get-points(ctx)
      points.insert(name1, p1)
      points.insert(name2, p2)
      ctx = _set-points(ctx, points)
    }
    (ctx: ctx)
  },)
}

/// Define point/object by rotation around a center (polymorphic)
#let _rotation(name, source, center, angle-deg) = {
  (ctx => {
    let center-pt = _resolve-point(ctx, center)

    // Detect source object type
    let obj-type = _get-object-type(ctx, source)

    if obj-type == none {
      // Try to resolve as a point reference (not in storage)
      let src = _resolve-point(ctx, source)
      let result = _transform.rotation-raw(src, center-pt, angle-deg)
      let points = _get-points(ctx)
      points.insert(name, result)
      ctx = _set-points(ctx, points)
    } else if obj-type == "point" {
      // Rotate point
      let src = _resolve-point(ctx, source)
      let result = _transform.rotation-raw(src, center-pt, angle-deg)
      let points = _get-points(ctx)
      points.insert(name, result)
      ctx = _set-points(ctx, points)
    } else if obj-type == "line" {
      // Rotate line (rotate both endpoints)
      let lines = _get-lines(ctx)
      let (p1, p2) = lines.at(source)
      let new-p1 = _transform.rotation-raw(p1, center-pt, angle-deg)
      let new-p2 = _transform.rotation-raw(p2, center-pt, angle-deg)
      lines.insert(name, (new-p1, new-p2))
      ctx = _set-lines(ctx, lines)
    } else if obj-type == "circle" {
      // Rotate circle (rotate center, keep radius)
      let circles = _get-circles(ctx)
      let c = circles.at(source)
      let new-center = _transform.rotation-raw(c.center, center-pt, angle-deg)
      circles.insert(name, (center: new-center, radius: c.radius))
      ctx = _set-circles(ctx, circles)
    } else if obj-type == "polygon" {
      // Rotate polygon by rotating all vertex points
      let polygons = _get-polygons(ctx)
      let vertex-names = polygons.at(source)
      let points = _get-points(ctx)

      // Rotate each vertex point in place
      for vname in vertex-names {
        if vname not in points {
          panic("Cannot rotate polygon '" + source + "': vertex point '" + vname + "' not found. All vertex points must be explicitly defined.")
        }
        let pt = points.at(vname)
        let rotated-pt = _transform.rotation-raw(pt, center-pt, angle-deg)
        points.insert(vname, rotated-pt)
      }
      ctx = _set-points(ctx, points)

      // Store rotated polygon with same vertex names
      polygons.insert(name, vertex-names)
      ctx = _set-polygons(ctx, polygons)
    }

    (ctx: ctx)
  },)
}

/// Define point by reflection across a line
#let _reflect(name, source, line-a, line-b) = {
  (ctx => {
    let src = _resolve-point(ctx, source)
    let la = _resolve-point(ctx, line-a)
    let lb = _resolve-point(ctx, line-b)
    let result = _transform.reflection-raw(src, la, lb)

    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define point by translation
#let _translate(name, source, vector) = {
  (ctx => {
    let src = _resolve-point(ctx, source)
    // Accepts a raw (dx, dy) vector or a pair of points ("A", "B") → B - A
    let vec = _resolve-vector(ctx, vector)
    let result = _transform.translation-raw(src, vec)

    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define point by homothety (scaling from center)
#let _homothety(name, source, center, factor) = {
  (ctx => {
    let src = _resolve-point(ctx, source)
    let ctr = _resolve-point(ctx, center)
    let result = _transform.homothety-raw(src, ctr, factor)

    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define point by projection onto line
#let _project(name, source, line-a, line-b) = {
  (ctx => {
    let src = _resolve-point(ctx, source)
    let la = _resolve-point(ctx, line-a)
    let lb = _resolve-point(ctx, line-b)
    let result = _transform.projection-raw(src, la, lb)

    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Duplicate any geometric object
#let _duplicate(target-name, source-name, points: auto) = {
  (ctx => {
    let obj-type = _get-object-type(ctx, source-name)

    if obj-type == none {
      panic("Object '" + source-name + "' not found. Cannot duplicate.")
    } else if obj-type == "point" {
      // Duplicate point
      let pt = _resolve-point(ctx, source-name)
      let point-dict = _get-points(ctx)
      point-dict.insert(target-name, pt)
      ctx = _set-points(ctx, point-dict)
    } else if obj-type == "line" {
      // Duplicate line
      let lines = _get-lines(ctx)
      let (p1, p2) = lines.at(source-name)
      lines.insert(target-name, (p1, p2))
      ctx = _set-lines(ctx, lines)
    } else if obj-type == "circle" {
      // Duplicate circle
      let circles = _get-circles(ctx)
      let c = circles.at(source-name)
      circles.insert(target-name, (center: c.center, radius: c.radius))
      ctx = _set-circles(ctx, circles)
    } else if obj-type == "polygon" {
      // Duplicate polygon - requires explicit point names
      let polygons = _get-polygons(ctx)
      let source-points = polygons.at(source-name)

      if points == auto {
        panic("For polygon duplication, must provide explicit point names: points: (\"A2\", \"B2\", ...)")
      }

      if points.len() != source-points.len() {
        panic("Point count mismatch: source polygon has " + str(source-points.len()) + " vertices, but " + str(points.len()) + " names provided.")
      }

      // Copy each vertex with new name
      let point-dict = _get-points(ctx)
      for (i, old-name) in source-points.enumerate() {
        let pt = _resolve-point(ctx, old-name)
        let new-name = points.at(i)
        point-dict.insert(new-name, pt)
      }
      ctx = _set-points(ctx, point-dict)

      // Store new polygon with new point names
      polygons.insert(target-name, points)
      ctx = _set-polygons(ctx, polygons)
    }

    (ctx: ctx)
  },)
}

/// Global point style state key
#let _point-style-key = "ctz-point-style"

/// Set up default point style
#let _set-up-point(style-spec) = {
  cetz.draw.set-ctx(ctx => {
    ctx.shared-state.insert(_point-style-key, style-spec)
    ctx
  })
}

/// Get current point style
#let _get-point-style(ctx) = {
  ctx.shared-state.at(_point-style-key, default: _draw.default-point-style)
}

/// Define a line by geometric construction (perpendicular, parallel, bisector, etc.)
#let _def-line(name1, name2, construction) = {
  (ctx => {
    let result = if construction.type == "perpendicular" {
      // Perpendicular to line through point
      let la = _resolve-point(ctx, construction.line.at(0))
      let lb = _resolve-point(ctx, construction.line.at(1))
      let through = _resolve-point(ctx, construction.through)
      let foot = _util.project-point-on-line(through, la, lb)
      // Line from through point, perpendicular to la-lb
      let dx = lb.at(0) - la.at(0)
      let dy = lb.at(1) - la.at(1)
      // Perpendicular direction
      let p1 = (through.at(0) - dy, through.at(1) + dx, 0)
      let p2 = (through.at(0) + dy, through.at(1) - dx, 0)
      (p1, p2)
    } else if construction.type == "parallel" {
      // Parallel to line through point
      let la = _resolve-point(ctx, construction.line.at(0))
      let lb = _resolve-point(ctx, construction.line.at(1))
      let through = _resolve-point(ctx, construction.through)
      let dx = lb.at(0) - la.at(0)
      let dy = lb.at(1) - la.at(1)
      let p1 = (through.at(0) - dx, through.at(1) - dy, 0)
      let p2 = (through.at(0) + dx, through.at(1) + dy, 0)
      (p1, p2)
    } else if construction.type == "bisector" {
      // Angle bisector: vertex is middle point
      let pa = _resolve-point(ctx, construction.points.at(0))
      let vertex = _resolve-point(ctx, construction.points.at(1))
      let pc = _resolve-point(ctx, construction.points.at(2))
      let bisector-pt = _util.angle-bisector-point(pa, vertex, pc)

      // Extend the bisector both ways so it is visible across the figure
      let dir-x = bisector-pt.at(0) - vertex.at(0)
      let dir-y = bisector-pt.at(1) - vertex.at(1)
      let dir-len = calc.sqrt(dir-x * dir-x + dir-y * dir-y)
      let dir = if _util.approx-zero(dir-len) { (1, 0) } else { (dir-x / dir-len, dir-y / dir-len) }

      let span = calc.max(_util.dist(vertex, pa), _util.dist(vertex, pc), 1) * 2.5
      let p1 = (vertex.at(0) - dir.at(0) * span, vertex.at(1) - dir.at(1) * span, vertex.at(2, default: 0))
      let p2 = (vertex.at(0) + dir.at(0) * span, vertex.at(1) + dir.at(1) * span, vertex.at(2, default: 0))
      (p1, p2)
    } else if construction.type == "mediator" {
      // Perpendicular bisector of segment
      let pa = _resolve-point(ctx, construction.segment.at(0))
      let pb = _resolve-point(ctx, construction.segment.at(1))
      let (p1, p2, mid) = _util.perpendicular-bisector(pa, pb)
      (p1, p2)
    } else {
      panic("Unknown line construction type: " + construction.type)
    }

    let points = _get-points(ctx)
    points.insert(name1, result.at(0))
    points.insert(name2, result.at(1))
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

// Line construction helpers
#let _perp(name1, name2, line, through) = _def-line(name1, name2, (type: "perpendicular", line: line, through: through))
#let _para(name1, name2, line, through) = _def-line(name1, name2, (type: "parallel", line: line, through: through))
#let _bisect(name1, name2, a, vertex, c) = _def-line(name1, name2, (type: "bisector", points: (a, vertex, c)))
#let _mediator(name1, name2, a, b) = _def-line(name1, name2, (type: "mediator", segment: (a, b)))

// =============================================================================
// DRAWING FUNCTIONS
// =============================================================================

/// Draw a polyline or named line (direct CeTZ wrapper)
#let _draw-line(..args) = {
  let pos = args.pos()
  let named = args.named()
  if pos.len() == 1 and type(pos.at(0)) == str {
    let name = pos.at(0)
    _drawing.draw-with-state(ctx => {
      let lines = _get-lines(ctx)
      if name in lines {
        let (p1, p2) = lines.at(name)
        ctx = _drawing._record-segment(ctx, p1, p2)
        (ctx, cetz.draw.line(p1, p2, ..named))
      } else {
        panic("Line '" + name + "' not found")
      }
    })
  } else {
    // Resolve point names ourselves: cetz >= 0.5 interprets bare strings
    // passed to line() as element names (border-intersection lines) and
    // panics when no such node exists.
    _drawing.draw-with-state(ctx => {
      let coords = pos.map(p => _resolve-point(ctx, p))
      for i in range(coords.len() - 1) {
        ctx = _drawing._record-segment(ctx, coords.at(i), coords.at(i + 1))
      }
      (ctx, cetz.draw.line(..coords, ..named))
    })
  }
}

/// Set point/label styling
#let _style(..style-args) = _drawing.set-style(cetz.draw, ..style-args)

/// Draw points
#let _points(..names) = _drawing.draw-points-styled(cetz.draw, _pt, ..names)

/// Draw labels
#let _labels(..args) = _drawing.label-points-styled(cetz.draw, _pt, ..args)

/// Draw angle
#let _angle(vertex, a, b, ..opts) = _drawing.mark-angle(cetz.draw, cetz.angle, _pt(vertex), _pt(a), _pt(b), ..opts)

/// Draw polygon
#let _polygon(..args) = {
  let pos = args.pos()
  let named = args.named()
  if pos.len() == 1 and type(pos.at(0)) == str {
    let name = pos.at(0)
    cetz.draw.get-ctx(ctx => {
      let polygons = _get-polygons(ctx)
      if name in polygons {
        let pts = polygons.at(name)
        _drawing.draw-polygon(cetz.draw, _pt, ..pts, ..named)
      } else {
        panic("Polygon '" + name + "' not found")
      }
    })
  } else {
    _drawing.draw-polygon(cetz.draw, _pt, ..pos, ..named)
  }
}

/// Draw a regular polygon by passing its vertex names
#let _draw-regular-polygon(names, ..opts) = {
  if names.len() < 3 {
    panic("Regular polygon needs at least three vertices")
  }
  let named = opts.named()
  let mark = named.at("mark", default: none)
  let mark-opts = named.at("mark-opts", default: (:))
  let draw-opts = (:)
  for (k, v) in named {
    if k not in ("mark", "mark-opts") {
      draw-opts.insert(k, v)
    }
  }

  _polygon(..names, ..draw-opts)

  if mark != none {
    let n = names.len()
    for i in range(n) {
      let a = names.at(i)
      let b = names.at(calc.rem(i + 1, n))
      _drawing.mark-segment(cetz.draw, _pt, a, b, mark: mark, ..mark-opts)
    }
  }
}

/// Fill polygon
#let _fill-polygon(..args) = {
  let pos = args.pos()
  let named = args.named()
  if pos.len() == 1 and type(pos.at(0)) == str {
    let name = pos.at(0)
    cetz.draw.get-ctx(ctx => {
      let polygons = _get-polygons(ctx)
      if name in polygons {
        let pts = polygons.at(name)
        _drawing.fill-polygon(cetz.draw, _pt, ..pts, ..named)
      } else {
        panic("Polygon '" + name + "' not found")
      }
    })
  } else {
    _drawing.fill-polygon(cetz.draw, _pt, ..pos, ..named)
  }
}

/// Fill a regular polygon by passing its vertex names
#let _fill-regular-polygon(names, ..opts) = {
  if names.len() < 3 {
    panic("Regular polygon needs at least three vertices")
  }
  _fill-polygon(..names, ..opts)
}

/// Parse a TikZ-like path spec (e.g., "A--B->C|-|D")
#let _parse-path-spec(spec) = {
  let s = spec.trim()
  let points = ()
  let connectors = ()
  let label-placements = (:)
  let point-style-overrides = (:)
  let ops = ("<->", "|-|", "|->", "<-|", "->", "<-", "--")

  let trim-left(s) = {
    while s.len() > 0 and s.slice(0, 1).trim() == "" {
      s = s.slice(1)
    }
    s
  }

  s = trim-left(s)
  while s.len() > 0 {
    let i = 0
    let depth = 0
    while i < s.len() and (depth > 0 or s.slice(i, i + 1) not in ("-", "<", ">", "|")) {
      let ch = s.slice(i, i + 1)
      if ch == "{" { depth += 1 }
      else if ch == "}" { depth -= 1 }
      i += 1
    }
    if depth != 0 {
      panic("Unbalanced label braces in path spec: " + spec)
    }
    if i == 0 {
      panic("Expected point name in path spec: " + spec)
    }
    let token = s.slice(0, i).trim()
    if token == "" {
      panic("Empty point name in path spec: " + spec)
    }
    let name = token
    if "{" in token {
      let start = none
      for j in range(token.len()) {
        if token.slice(j, j + 1) == "{" {
          start = j
          break
        }
      }
      if start == none {
        panic("Invalid label placement in path spec: " + spec)
      }
      let end = token.len() - 1
      if not token.ends-with("}") {
        panic("Invalid label placement in path spec: " + spec)
      }
      name = token.slice(0, start).trim()
      let spec = token.slice(start + 1, end).trim()
      if name == "" {
        panic("Empty point name in path spec: " + spec)
      }
      if spec != "" {
        let pos = none
        let style = none
        let parts = spec.split(",")
        for part in parts {
          let item = part.trim()
          if item == "" { continue }
          if ":" in item {
            let key = item.split(":").at(0).trim()
            let val = item.split(":").at(1).trim()
            if val.starts-with("\"") and val.ends-with("\"") and val.len() >= 2 {
              val = val.slice(1, val.len() - 1)
            }
            if key == "pos" {
              pos = val
            } else if key == "style" or key == "point" {
              style = if val == "none" { none } else { val }
            }
          } else {
            pos = item
          }
        }
        if pos != none and pos != "" {
          label-placements.insert(name, pos)
        }
        if style != none {
          point-style-overrides.insert(name, style)
        }
      }
    }
    points.push(name)
    s = trim-left(s.slice(i))
    if s.len() == 0 { break }

    let connector = none
    for op in ops {
      if s.starts-with(op) {
        connector = op
        s = s.slice(op.len())
        break
      }
    }
    if connector == none {
      panic("Expected connector in path spec: " + spec)
    }
    connectors.push(connector)
    s = trim-left(s)
  }

  if points.len() != connectors.len() + 1 {
    panic("Invalid path spec: " + spec)
  }

  (points: points, connectors: connectors, label-placements: label-placements, point-style-overrides: point-style-overrides)
}

/// Draw a path with per-segment arrows using a TikZ-like string
#let _path(spec, ..opts) = {
  if type(spec) != str {
    panic("ctz-draw-path expects a string like \"A--B->C|-|D\"")
  }
  let parsed = _parse-path-spec(spec)
  let points = parsed.points
  let connectors = parsed.connectors
  let named = opts.named()
  let draw-points = named.at("points", default: true)
  let draw-labels = named.at("labels", default: true)
  let default-label-pos = named.at("label-pos", default: "below")
  let label-overrides = named.at("label-overrides", default: (:))
  let point-style = named.at("point-style", default: auto)
  let point-color = named.at("point-color", default: black)
  let sketchy = named.at("sketchy", default: false)
  let roughness = named.at("roughness", default: _draw.default-main-levee-roughness)
  let seed = named.at("seed", default: _draw.default-main-levee-seed)
  let style = (:)
  for (k, v) in named {
    if k not in ("points", "labels", "label-pos", "label-overrides", "point-style", "point-color", "sketchy", "roughness", "seed") {
      style.insert(k, v)
    }
  }

  for i in range(points.len() - 1) {
    let arrows = connectors.at(i)
    if arrows == "--" {
      arrows = none
    }
    if sketchy and arrows == none {
      // Draw sketchy segment (no arrows support for sketchy yet)
      cetz.draw.get-ctx(ctx => {
        let p1 = _resolve-point(ctx, points.at(i))
        let p2 = _resolve-point(ctx, points.at(i + 1))
        _drawing.draw-sketchy-line(cetz.draw, p1, p2, roughness: roughness, seed: seed + i, ..style)
      })
    } else {
      _drawing.draw-segment(cetz.draw, _pt, points.at(i), points.at(i + 1), arrows: arrows, ..style)
    }
  }

  if draw-points {
    let connectors-len = connectors.len()
    for i in range(points.len()) {
      let name = points.at(i)
      let has-bar = false
      if i > 0 {
        let prev = connectors.at(i - 1)
        let prev-end = if prev in ("|-|", "<-|") { "|" } else { none }
        if prev-end == "|" { has-bar = true }
      }
      if i < connectors-len {
        let next = connectors.at(i)
        let next-start = if next in ("|-|", "|->") { "|" } else { none }
        if next-start == "|" { has-bar = true }
      }

      let default-style = if has-bar { none } else { "cross" }
      let final-style = if point-style == auto { default-style } else { point-style }
      if name in parsed.point-style-overrides {
        final-style = parsed.point-style-overrides.at(name)
      }

      if final-style != none {
        _drawing.draw-point(cetz.draw, _pt(name), style: final-style, color: point-color)
      }
    }
  }

  if draw-labels {
    let placements = (:)
    for name in points {
      placements.insert(name, default-label-pos)
    }
    for (k, v) in parsed.label-placements {
      placements.insert(k, v)
    }
    for (k, v) in label-overrides {
      placements.insert(k, v)
    }
    _drawing.label-points-styled(cetz.draw, _pt, ..points, ..placements)
  }
}

/// Draw segment
#let _segment(a, b, ..opts) = _drawing.draw-segment(cetz.draw, _pt, a, b, ..opts)

/// Draw measurement segment
#let _measure-segment(a, b, ..opts) = _drawing.draw-measure-segment(cetz.draw, _pt, a, b, ..opts)

/// Draw line with extension
#let _line-add(a, b, ..opts) = _drawing.draw-line-add(cetz.draw, _pt, a, b, ..opts)

/// Draw arc through points
#let _arc(center, start, end, ..opts) = _drawing.draw-arc-through(cetz.draw, _pt, center, start, end, ..opts)

/// Draw arc with radius
#let _arc-r(center, radius, start-angle, end-angle, ..opts) = _drawing.draw-arc-r(cetz.draw, center, radius, start-angle, end-angle, ..opts)

/// Draw circle with radius
#let _circle-r(center, radius, ..opts) = _drawing.draw-circle-r(cetz.draw, center, radius, ..opts)

/// Draw circle through point
#let _circle-through(center, through, ..opts) = _drawing.draw-circle-through(cetz.draw, _pt, center, through, ..opts)

/// Draw circle with diameter
#let _circle-diameter(a, b, ..opts) = _drawing.draw-circle-diameter(cetz.draw, _pt, a, b, ..opts)

/// Draw a named circle
#let _draw-circle(name, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let circles = _get-circles(ctx)
    if name in circles {
      let c = circles.at(name)
      _drawing.draw-circle-r(cetz.draw, c.center, c.radius, ..opts)
    } else {
      panic("Circle '" + name + "' not found")
    }
  })
}

/// Draw a named conic (ellipse, parabola, or projectile)
#let _draw-conic(name, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let conics = _get-conics(ctx)
    if name in conics {
      let c = conics.at(name)
      if c.type == "ellipse" {
        _drawing.draw-ellipse(cetz.draw, c.center, c.rx, c.ry, angle: c.angle, ..opts)
      } else if c.type == "parabola" {
        _drawing.draw-parabola-focus-directrix(
          cetz.draw,
          c.focus,
          c.directrix.at(0),
          c.directrix.at(1),
          extent: c.extent,
          steps: c.steps,
          ..opts
        )
      } else if c.type == "projectile" {
        _drawing.draw-projectile(
          cetz.draw,
          c.origin,
          c.velocity,
          gravity: c.gravity,
          t-max: c.t-max,
          steps: c.steps,
          y-floor: c.y-floor,
          vectors: c.vectors,
          vector-count: c.vector-count,
          vector-scale: c.vector-scale,
          ..opts
        )
      } else {
        panic("Unknown conic type '" + c.type + "' for '" + name + "'")
      }
    } else {
      panic("Conic '" + name + "' not found")
    }
  })
}

/// Draw circumcircle
#let _circumcircle(a, b, c, ..opts) = _drawing.draw-circumcircle(cetz.draw, _pt, a, b, c, ..opts)

/// Draw incircle
#let _incircle(a, b, c, ..opts) = _drawing.draw-incircle(cetz.draw, _pt, a, b, c, ..opts)

/// Draw semicircle
#let _semicircle(a, b, ..opts) = _drawing.draw-semicircle(cetz.draw, _pt, a, b, ..opts)

/// Fully polymorphic draw function - draws named objects or unnamed constructs
///
/// Named objects:
///   ctz-draw("C1", stroke: blue)
///
/// Unnamed constructs via named parameters:
///   ctz-draw(path: "A--B--C", stroke: black)
///   ctz-draw(line: ("A", "B", "C"), stroke: red)
///   ctz-draw(points: ("A", "B", "C"))                              // Draw multiple points
///   ctz-draw(points: ("A", "B", "C"), labels: true)               // Draw points with labels
///   ctz-draw(points: ("A", "B", "C"), labels: (A: "top"))        // Custom label positions
///   ctz-draw(circle-through: ("O", "A"), stroke: blue)
///   ctz-draw(circle-r: ((0, 0), 2), stroke: green)
///   ctz-draw(circle-diameter: ("A", "B"), stroke: purple)
///   ctz-draw(circumcircle: ("A", "B", "C"), stroke: blue)
///   ctz-draw(incircle: ("A", "B", "C"), stroke: red)
///   ctz-draw(ellipse: ("O", 3, 2, 30deg), stroke: green)
///   ctz-draw(parabola: ("F", ("A", "B"), 4), stroke: orange)
///   ctz-draw(projectile: (origin: (0, 0), velocity: (3, 6), y-floor: 0, vectors: true), stroke: blue)
///   ctz-draw(arc: (center: "O", start: "A", end: "B"), stroke: black)
///   ctz-draw(arc-r: ((0, 0), 2, 0, 90), stroke: black)
///   ctz-draw(semicircle: ("A", "B"), stroke: blue)
///   ctz-draw(segment: ("A", "B"), stroke: black)
#let _polymorphic-draw(..args) = {
  let pos = args.pos()
  let named = args.named()

  // Extract sketchy parameters
  let sketchy = named.at("sketchy", default: false)
  let roughness = named.at("roughness", default: _draw.default-main-levee-roughness)
  let seed = named.at("seed", default: _draw.default-main-levee-seed)

  // Remove sketchy params from named args to pass to drawing functions
  let draw-opts = (:)
  for (k, v) in named {
    if k not in ("sketchy", "roughness", "seed") {
      draw-opts.insert(k, v)
    }
  }

  // Case 1: Named object (first positional arg is string)
  if pos.len() > 0 and type(pos.at(0)) == str {
    let name = pos.at(0)
    cetz.draw.get-ctx(ctx => {
      let obj-type = _get-object-type(ctx, name)

      if obj-type == none {
        panic("Object '" + name + "' not found. No point, line, circle, polygon, or conic with this name exists.")
      } else if obj-type == "circle" {
        if sketchy {
          // Get circle data and draw sketchy
          let circles = _get-circles(ctx)
          let circ = circles.at(name)
          _drawing.draw-sketchy-circle(cetz.draw, circ.center, circ.radius, roughness: roughness, seed: seed, ..draw-opts)
        } else {
          _draw-circle(name, ..draw-opts)
        }
      } else if obj-type == "conic" {
        // Conics use sketchy ellipse when applicable
        if sketchy {
          let conics = _get-conics(ctx)
          let conic-data = conics.at(name)
          if conic-data.type == "ellipse" {
            _drawing.draw-sketchy-ellipse(cetz.draw, conic-data.center, conic-data.rx, conic-data.ry, angle: conic-data.angle, roughness: roughness, seed: seed, ..draw-opts)
          } else {
            _draw-conic(name, ..draw-opts)  // Parabolas not yet sketchy
          }
        } else {
          _draw-conic(name, ..draw-opts)
        }
      } else if obj-type == "line" {
        if sketchy {
          let lines = _get-lines(ctx)
          let (p1, p2) = lines.at(name)
          _drawing.draw-sketchy-line(cetz.draw, p1, p2, roughness: roughness, seed: seed, ..draw-opts)
        } else {
          _draw-line(name, ..draw-opts)
        }
      } else if obj-type == "polygon" {
        if sketchy {
          let polygons = _get-polygons(ctx)
          let vertex-names = polygons.at(name)
          let vertices = vertex-names.map(v => _resolve-point(ctx, v))
          _drawing.draw-sketchy-polygon(cetz.draw, vertices, roughness: roughness, seed: seed, close: true, ..draw-opts)
        } else {
          _polygon(name, ..draw-opts)
        }
      } else if obj-type == "point" {
        _points(name, ..draw-opts)
      }
    })
  }
  // Case 2: Unnamed construct via named parameter
  else if "path" in named {
    let path-spec = named.path
    let other-opts = (:)
    for (k, v) in named {
      if k != "path" {
        other-opts.insert(k, v)
      }
    }
    _path(path-spec, ..other-opts)
  }
  else if "line" in named {
    let line-points = named.line
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("line", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let vertices = line-points.map(p => _resolve-point(ctx, p))
        _drawing.draw-sketchy-polygon(cetz.draw, vertices, roughness: roughness, seed: seed, close: false, ..other-opts)
      })
    } else {
      // Use draw-polygon with close: false for polylines through named points
      other-opts.insert("close", false)
      _drawing.draw-polygon(cetz.draw, _pt, ..line-points, ..other-opts)
    }
  }
  else if "points" in named {
    let point-names = named.points
    let labels-spec = named.at("labels", default: false)

    // Ensure point-names is an array
    if type(point-names) != array {
      point-names = (point-names,)
    }

    // Draw the points, forwarding style options (shape:, size:, color:, ...)
    let style-opts = (:)
    for (k, v) in named {
      if k not in ("points", "labels", "sketchy", "roughness", "seed") {
        style-opts.insert(k, v)
      }
    }
    _points(..point-names, ..style-opts)

    // Draw labels if requested
    if labels-spec != false {
      if labels-spec == true {
        // Draw all labels with default positioning
        _labels(..point-names)
      } else if type(labels-spec) == dictionary {
        // Draw labels with custom positioning
        _labels(..point-names, ..labels-spec)
      }
    }
  }
  else if "labels" in named {
    // Standalone labels (without points parameter)
    let labels-spec = named.labels

    if type(labels-spec) == array {
      // Array with point names and options
      _labels(..labels-spec)
    } else if type(labels-spec) == dictionary {
      // Dictionary keyed by point name (assumes points were drawn separately)
      let point-names = labels-spec.keys()
      if point-names.len() > 0 {
        _labels(..point-names, ..labels-spec)
      }
    }
  }
  else if "circle-through" in named {
    let pts = named.at("circle-through")
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("circle-through", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let center = _resolve-point(ctx, pts.at(0))
        let through = _resolve-point(ctx, pts.at(1))
        let radius = _util.dist(center, through)
        _drawing.draw-sketchy-circle(cetz.draw, center, radius, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _circle-through(pts.at(0), pts.at(1), ..other-opts)
    }
  }
  else if "circle-r" in named {
    let spec = named.at("circle-r")
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("circle-r", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let center = _resolve-point(ctx, spec.at(0))
        let radius = spec.at(1)
        let r = if type(radius) == length { radius / 1cm } else { radius }
        _drawing.draw-sketchy-circle(cetz.draw, center, r, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _circle-r(spec.at(0), spec.at(1), ..other-opts)
    }
  }
  else if "ellipse" in named {
    let spec = named.at("ellipse")
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("ellipse", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    cetz.draw.get-ctx(ctx => {
      let center = none
      let rx = none
      let ry = none
      let angle = 0deg
      let steps = 120

      if type(spec) == dictionary {
        center = spec.center
        if "radius" in spec and type(spec.radius) == array and spec.radius.len() >= 2 {
          rx = spec.radius.at(0)
          ry = spec.radius.at(1)
        } else {
          rx = spec.rx
          ry = spec.ry
        }
        angle = spec.at("angle", default: 0deg)
        steps = spec.at("steps", default: 120)
      } else if type(spec) == array and spec.len() >= 3 {
        center = spec.at(0)
        rx = spec.at(1)
        ry = spec.at(2)
        angle = spec.at(3, default: 0deg)
        steps = spec.at(4, default: 120)
      } else {
        panic("ctz-draw(ellipse: ...) expects (center, rx, ry, angle?) or a dictionary")
      }

      let c = _resolve-point(ctx, center)
      let rx-num = if type(rx) == length { rx / 1cm } else { rx }
      let ry-num = if type(ry) == length { ry / 1cm } else { ry }
      let ang = _util.to-angle(angle)
      if sketchy {
        _drawing.draw-sketchy-ellipse(cetz.draw, c, rx-num, ry-num, angle: ang, roughness: roughness, seed: seed, ..other-opts)
      } else {
        _drawing.draw-ellipse(cetz.draw, c, rx-num, ry-num, angle: ang, steps: steps, ..other-opts)
      }
    })
  }
  else if "parabola" in named {
    let spec = named.at("parabola")
    let other-opts = (:)
    for (k, v) in named {
      if k != "parabola" {
        other-opts.insert(k, v)
      }
    }
    cetz.draw.get-ctx(ctx => {
      let focus = none
      let directrix = none
      let extent = auto
      let steps = 120

      if type(spec) == dictionary {
        focus = spec.focus
        directrix = spec.directrix
        extent = spec.at("extent", default: auto)
        steps = spec.at("steps", default: 120)
      } else if type(spec) == array and spec.len() >= 2 {
        focus = spec.at(0)
        directrix = spec.at(1)
        extent = spec.at(2, default: auto)
        steps = spec.at(3, default: 120)
      } else {
        panic("ctz-draw(parabola: ...) expects (focus, directrix, extent?) or a dictionary")
      }

      let f = _resolve-point(ctx, focus)
      let (a, b) = _parse-line(ctx, directrix)
      let ext = if type(extent) == length { extent / 1cm } else { extent }
      _drawing.draw-parabola-focus-directrix(cetz.draw, f, a, b, extent: ext, steps: steps, ..other-opts)
    })
  }
  else if "projectile" in named {
    let spec = named.at("projectile")
    let other-opts = (:)
    for (k, v) in named {
      if k != "projectile" {
        other-opts.insert(k, v)
      }
    }
    cetz.draw.get-ctx(ctx => {
      let origin = none
      let velocity = none
      let gravity = 9.81
      let t-max = auto
      let steps = 80
      let y-floor = none
      let vectors = false
      let vector-count = 5
      let vector-scale = 0.12

      if type(spec) == dictionary {
        origin = spec.origin
        velocity = spec.velocity
        gravity = spec.at("gravity", default: 9.81)
        t-max = spec.at("t-max", default: auto)
        steps = spec.at("steps", default: 80)
        y-floor = spec.at("y-floor", default: none)
        vectors = spec.at("vectors", default: false)
        vector-count = spec.at("vector-count", default: 5)
        vector-scale = spec.at("vector-scale", default: 0.12)
      } else if type(spec) == array and spec.len() >= 2 {
        origin = spec.at(0)
        velocity = spec.at(1)
        t-max = spec.at(2, default: auto)
        steps = spec.at(3, default: 80)
      } else {
        panic("ctz-draw(projectile: ...) expects (origin, velocity, t-max?) or a dictionary")
      }

      let o = _resolve-point(ctx, origin)
      let v = _resolve-vector(ctx, velocity)
      let y-floor-num = if y-floor != none and type(y-floor) == length { y-floor / 1cm } else { y-floor }
      _drawing.draw-projectile(
        cetz.draw,
        o,
        v,
        gravity: gravity,
        t-max: t-max,
        steps: steps,
        y-floor: y-floor-num,
        vectors: vectors,
        vector-count: vector-count,
        vector-scale: vector-scale,
        ..other-opts
      )
    })
  }
  else if "circle-diameter" in named {
    let pts = named.at("circle-diameter")
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("circle-diameter", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let p1 = _resolve-point(ctx, pts.at(0))
        let p2 = _resolve-point(ctx, pts.at(1))
        let center = ((p1.at(0) + p2.at(0)) / 2, (p1.at(1) + p2.at(1)) / 2)
        let radius = _util.dist(p1, p2) / 2
        _drawing.draw-sketchy-circle(cetz.draw, center, radius, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _circle-diameter(pts.at(0), pts.at(1), ..other-opts)
    }
  }
  else if "circumcircle" in named {
    let pts = named.circumcircle
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("circumcircle", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let pa = _resolve-point(ctx, pts.at(0))
        let pb = _resolve-point(ctx, pts.at(1))
        let pc = _resolve-point(ctx, pts.at(2))
        let center = _triangle.circumcenter-raw(pa, pb, pc)
        let radius = _util.dist(center, pa)
        _drawing.draw-sketchy-circle(cetz.draw, center, radius, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _circumcircle(pts.at(0), pts.at(1), pts.at(2), ..other-opts)
    }
  }
  else if "incircle" in named {
    let pts = named.incircle
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("incircle", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let pa = _resolve-point(ctx, pts.at(0))
        let pb = _resolve-point(ctx, pts.at(1))
        let pc = _resolve-point(ctx, pts.at(2))
        let center = _triangle.incenter-raw(pa, pb, pc)
        let radius = _triangle.inradius-raw(pa, pb, pc)
        _drawing.draw-sketchy-circle(cetz.draw, center, radius, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _incircle(pts.at(0), pts.at(1), pts.at(2), ..other-opts)
    }
  }
  else if "arc" in named {
    let spec = named.arc
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("arc", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let center = _resolve-point(ctx, spec.center)
        let start-pt = _resolve-point(ctx, spec.start)
        let end-pt = _resolve-point(ctx, spec.end)
        let radius = _util.dist(center, start-pt)
        let start-angle = _util.angle-of(start-pt.at(0) - center.at(0), start-pt.at(1) - center.at(1))
        let end-angle = _util.angle-of(end-pt.at(0) - center.at(0), end-pt.at(1) - center.at(1))
        _drawing.draw-sketchy-arc(cetz.draw, center, radius, start-angle, end-angle, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _arc(spec.center, spec.start, spec.end, ..other-opts)
    }
  }
  else if "arc-r" in named {
    let spec = named.at("arc-r")
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("arc-r", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let center = _resolve-point(ctx, spec.at(0))
        let radius = spec.at(1)
        let r = if type(radius) == length { radius / 1cm } else { radius }
        let start-angle = spec.at(2)
        let end-angle = spec.at(3)
        _drawing.draw-sketchy-arc(cetz.draw, center, r, start-angle, end-angle, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _arc-r(spec.at(0), spec.at(1), spec.at(2), spec.at(3), ..other-opts)
    }
  }
  else if "semicircle" in named {
    let pts = named.semicircle
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("semicircle", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let p1 = _resolve-point(ctx, pts.at(0))
        let p2 = _resolve-point(ctx, pts.at(1))
        let center = ((p1.at(0) + p2.at(0)) / 2, (p1.at(1) + p2.at(1)) / 2)
        let radius = _util.dist(p1, p2) / 2
        let start-angle = _util.angle-of(p1.at(0) - center.at(0), p1.at(1) - center.at(1))
        let end-angle = start-angle + 180deg
        _drawing.draw-sketchy-arc(cetz.draw, center, radius, start-angle, end-angle, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _semicircle(pts.at(0), pts.at(1), ..other-opts)
    }
  }
  else if "segment" in named {
    let pts = named.segment
    let other-opts = (:)
    for (k, v) in named {
      if k not in ("segment", "sketchy", "roughness", "seed") {
        other-opts.insert(k, v)
      }
    }
    if sketchy {
      cetz.draw.get-ctx(ctx => {
        let p1 = _resolve-point(ctx, pts.at(0))
        let p2 = _resolve-point(ctx, pts.at(1))
        _drawing.draw-sketchy-line(cetz.draw, p1, p2, roughness: roughness, seed: seed, ..other-opts)
      })
    } else {
      _segment(pts.at(0), pts.at(1), ..other-opts)
    }
  }
  else {
    panic("ctz-draw() requires either a named object (string) or a type parameter (path:, line:, circle-through:, etc.)")
  }
}

/// Draw sector
#let _sector(center, start, end, ..opts) = _drawing.draw-sector(cetz.draw, _pt, center, start, end, ..opts)

/// Mark segment
#let _mark-segment(a, b, ..opts) = _drawing.mark-segment(cetz.draw, _pt, a, b, ..opts)

/// Mark right angle
#let _mark-right-angle(a, vertex, c, ..opts) = _drawing.mark-right-angle(cetz.draw, _pt, a, vertex, c, ..opts)

/// Fill angle
#let _fill-angle(vertex, a, c, ..opts) = _drawing.fill-angle(cetz.draw, cetz.angle, _pt, vertex, a, c, ..opts)

/// Label segment
#let _label-segment(a, b, ..opts) = _drawing.label-segment(cetz.draw, _pt, a, b, ..opts)

/// Label angle
#let _label-angle(vertex, a, c, ..opts) = _drawing.label-angle-at(cetz.draw, _pt, vertex, a, c, ..opts)

/// Label a named circle
#let _label-circle(name, label, pos: "above", dist: 0.2, offset: (0, 0)) = {
  cetz.draw.get-ctx(ctx => {
    let circles = _get-circles(ctx)
    if name in circles {
      let c = circles.at(name)
      let base = _draw.anchor-offset(pos, c.radius + dist)
      let label-pos = (
        c.center.at(0) + base.at(0) + offset.at(0),
        c.center.at(1) + base.at(1) + offset.at(1),
        c.center.at(2, default: 0),
      )
      let anchor = _draw.ctz-pos-to-anchor(pos)
      cetz.draw.content(label-pos, label, anchor: anchor)
    } else {
      panic("Circle '" + name + "' not found")
    }
  })
}

/// Label a named polygon
#let _label-polygon(name, label, pos: "center", dist: 0.2, offset: (0, 0)) = {
  cetz.draw.get-ctx(ctx => {
    let polygons = _get-polygons(ctx)
    if name in polygons {
      let pts = polygons.at(name).map(p => _resolve-point(ctx, p))
      if pts.len() == 0 {
        return
      }
      let sum = (0, 0, 0)
      for p in pts {
        sum = (sum.at(0) + p.at(0), sum.at(1) + p.at(1), sum.at(2) + p.at(2, default: 0))
      }
      let center = (sum.at(0) / pts.len(), sum.at(1) / pts.len(), sum.at(2) / pts.len())

      let base = if pos == "center" or pos == "centroid" { (0, 0) } else { _draw.anchor-offset(pos, dist) }
      let anchor = if pos == "center" or pos == "centroid" { "center" } else { _draw.ctz-pos-to-anchor(pos) }
      let label-pos = (
        center.at(0) + base.at(0) + offset.at(0),
        center.at(1) + base.at(1) + offset.at(1),
        center.at(2, default: 0),
      )
      cetz.draw.content(label-pos, label, anchor: anchor)
    } else {
      panic("Polygon '" + name + "' not found")
    }
  })
}

// =============================================================================
// CALCULATIONS (return values via context)
// =============================================================================

#let _calc-length(a, b) = (ctx => {
  let pa = _resolve-point(ctx, a)
  let pb = _resolve-point(ctx, b)
  (ctx: ctx, value: _util.dist(pa, pb))
},)

#let _calc-angle(a, b, c) = (ctx => {
  let pa = _resolve-point(ctx, a)
  let pb = _resolve-point(ctx, b)
  let pc = _resolve-point(ctx, c)
  (ctx: ctx, value: _util.angle-at-vertex(pa, pb, pc))
},)

#let _calc-area(a, b, c) = (ctx => {
  let pa = _resolve-point(ctx, a)
  let pb = _resolve-point(ctx, b)
  let pc = _resolve-point(ctx, c)
  (ctx: ctx, value: _util.triangle-area(pa, pb, pc))
},)

#let _calc-slope(a, b) = (ctx => {
  let pa = _resolve-point(ctx, a)
  let pb = _resolve-point(ctx, b)
  (ctx: ctx, value: _util.slope-angle(pa, pb))
},)

#let _calc-ratio(a, b, c) = (ctx => {
  let pa = _resolve-point(ctx, a)
  let pb = _resolve-point(ctx, b)
  let pc = _resolve-point(ctx, c)
  (ctx: ctx, value: _util.ratio(pa, pb, pc))
},)

// =============================================================================
// GRID AND AXES
// =============================================================================

#let _grid(..opts) = _drawing.draw-grid(cetz.draw, ..opts)
#let _axes(..opts) = _drawing.draw-axes(cetz.draw, ..opts)
#let _axis-x(..opts) = _drawing.draw-axis-x(cetz.draw, ..opts)
#let _axis-y(..opts) = _drawing.draw-axis-y(cetz.draw, ..opts)
#let _hline(y, ..opts) = _drawing.draw-hline(cetz.draw, y, ..opts)
#let _vline(x, ..opts) = _drawing.draw-vline(cetz.draw, x, ..opts)
#let _draw-text(x, y, content, ..opts) = _drawing.draw-text(cetz.draw, x, y, content, ..opts)

// =============================================================================
// CLIPPING
// =============================================================================

/// Set global clip region
#let _set-clip(xmin, ymin, xmax, ymax) = _drawing.set-clip-region(cetz.draw, xmin, ymin, xmax, ymax)

/// Clear global clip region
#let _clear-clip() = _drawing.clear-clip-region(cetz.draw)

/// Show clip boundary
#let _show-clip(stroke: gray + 0.5pt) = _drawing.draw-global-clip-boundary(cetz.draw, stroke: stroke)

/// Draw line with global clip
#let _ctz-line(a, b, add: (10, 10), stroke: black) = _drawing.draw-line-global-clip(cetz.draw, _pt, a, b, add: add, stroke: stroke)

/// Draw segment with global clip
#let _seg(a, b, stroke: black) = _drawing.draw-segment-global-clip(cetz.draw, _pt, a, b, stroke: stroke)

/// Draw clipped line (manual bounds)
#let _clipped-line(p1, p2, xmin, ymin, xmax, ymax, stroke: black) = _drawing.draw-clipped-line(cetz.draw, p1, p2, xmin, ymin, xmax, ymax, stroke: stroke)

/// Draw clipped line with extension (manual bounds)
#let _clipped-line-add(a, b, xmin, ymin, xmax, ymax, add: (10, 10), stroke: black) = _drawing.draw-clipped-line-add(cetz.draw, _pt, a, b, xmin, ymin, xmax, ymax, add: add, stroke: stroke)

/// Draw clip boundary
#let _clip-boundary(xmin, ymin, xmax, ymax, stroke: black + 0.5pt) = _drawing.draw-clip-boundary(cetz.draw, xmin, ymin, xmax, ymax, stroke: stroke)

/// Raw clipping algorithm
#let _clip-line-to-rect = _drawing.clip-line-to-rect

// =============================================================================
// RAW ALGORITHMS (no context needed)
// =============================================================================

#let _algorithms = (
  // Intersections
  line-line: _intersection.line-line-raw,
  line-circle: _intersection.line-circle-raw,
  circle-circle: _intersection.circle-circle-raw,
  // Triangle centers
  centroid: _triangle.centroid-raw,
  circumcenter: _triangle.circumcenter-raw,
  incenter: _triangle.incenter-raw,
  orthocenter: _triangle.orthocenter-raw,
  inradius: _triangle.inradius-raw,
  circumradius: _triangle.circumradius-raw,
  euler-center: _triangle.euler-center-raw,
  euler-radius: _triangle.euler-radius-raw,
  lemoine: _triangle.lemoine-raw,
  nagel: _triangle.nagel-raw,
  gergonne: _triangle.gergonne-raw,
  spieker: _triangle.spieker-raw,
  feuerbach: _triangle.feuerbach-raw,
  mittenpunkt: _triangle.mittenpunkt-raw,
  excenter: _triangle.excenter-raw,
  exradius: _triangle.exradius-raw,
  // Special triangles
  medial-triangle: _triangle.medial-triangle-raw,
  orthic-triangle: _triangle.orthic-triangle-raw,
  intouch-triangle: _triangle.intouch-triangle-raw,
  excentral-triangle: _triangle.excentral-triangle-raw,
  tangential-triangle: _triangle.tangential-triangle-raw,
  // Transformations
  rotation: _transform.rotation-raw,
  reflection: _transform.reflection-raw,
  translation: _transform.translation-raw,
  homothety: _transform.homothety-raw,
  projection: _transform.projection-raw,
  point-on-circle: _transform.point-on-circle-raw,
  // Circle definitions
  circle-through: _circle.circle-through-raw,
  circle-diameter: _circle.circle-diameter-raw,
  circle-circum: _circle.circle-circum-raw,
  circle-in: _circle.circle-in-raw,
  circle-ex: _circle.circle-ex-raw,
  circle-euler: _circle.circle-euler-raw,
  tangent-from: _circle.tangent-from-point-raw,
  tangent-at: _circle.tangent-at-point-raw,
  radical-axis: _circle.radical-axis-raw,
  apollonius: _circle.apollonius-circle-raw,
  // Utility calculations
  midpoint: _util.midpoint,
  dist: _util.dist,
  angle-at-vertex: _util.angle-at-vertex,
  slope-angle: _util.slope-angle,
  triangle-area: _util.triangle-area,
  polygon-area: _util.polygon-area,
  equilateral-point: _util.equilateral-point,
  square-points: _util.square-points,
  golden-ratio-point: _util.golden-ratio-point,
  barycentric-point: _util.barycentric-point,
  regular-polygon-vertices: _util.regular-polygon-vertices,
  central-symmetry: _util.central-symmetry,
  circle-inversion: _util.circle-inversion,
)

// Re-export utility functions
#let _midpoint-raw = _util.midpoint
#let _dist = _util.dist
#let _angle-to = _util.angle-to
#let _project-point-on-line = _util.project-point-on-line
#let _rotate-point = _util.rotate-point

// =============================================================================
// PUBLIC API (ctz- prefix)
// =============================================================================

/// Package version
#let ctz-version = _version

// =============================================================================
// STYLE CONFIGURATION EXPORTS
// =============================================================================
// These variables control the default appearance. Users can override them:
//   #import "@preview/ctz-euclide:0.1.5": *
//   #let ctz-default-point-stroke-width = 1.2pt  // thicker crosses

/// Default stroke width for point markers (crosses, plus signs)
#let ctz-default-point-stroke-width = _draw.default-point-stroke-width

/// Default stroke width for tick marks on segments and arcs
#let ctz-default-mark-stroke-width = _draw.default-mark-stroke-width

/// Default point size in canvas units
#let ctz-default-point-size = _draw.default-point-size

/// Default point size in pt (for path markers)
#let ctz-default-point-size-pt = _draw.default-point-size-pt

/// Default smaller point size in pt (for dots, circles, squares)
#let ctz-default-point-size-small-pt = _draw.default-point-size-small-pt

/// Default color for points
#let ctz-default-point-color = _draw.default-point-color

/// Default color for lines and segments
#let ctz-default-line-color = _draw.default-line-color

/// Default color for construction marks (tick marks, arc marks)
#let ctz-default-mark-color = _draw.default-mark-color

/// Default point shape ("cross", "dot", "circle", "plus", "square", "diamond", "triangle")
#let ctz-default-point-shape = _draw.default-point-shape

// =============================================================================
// MAIN LEVÉE (HAND-DRAWN STYLE) EXPORTS
// =============================================================================

/// Default main-levée enabled state
#let ctz-default-main-levee = _draw.default-main-levee

/// Default main-levée roughness (0 = smooth, 1-2 = typical hand-drawn)
#let ctz-default-main-levee-roughness = _draw.default-main-levee-roughness

/// Default main-levée seed for reproducible randomness
#let ctz-default-main-levee-seed = _draw.default-main-levee-seed

/// Default clip-to-canvas bounds (none disables auto canvas clipping)
/// Accepts (xmin, ymin, xmax, ymax) or dictionary with xmin/ymin/xmax/ymax.
#let ctz-default-clip-canvas = none

/// Enable/disable main-levée (hand-drawn) mode
/// Usage: ctz-main-levee(true) or ctz-main-levee(true, roughness: 1.5, seed: 123)
#let ctz-main-levee(enabled: true, roughness: auto, seed: auto) = _drawing.set-main-levee(cetz.draw, enabled: enabled, roughness: roughness, seed: seed)

/// Draw sketchy line (explicit main-levée)
#let ctz-sketchy-line(p1, p2, roughness: _draw.default-main-levee-roughness, seed: _draw.default-main-levee-seed, ..style) = _drawing.draw-sketchy-line(cetz.draw, p1, p2, roughness: roughness, seed: seed, ..style)

/// Draw sketchy circle (explicit main-levée)
#let ctz-sketchy-circle(center, radius, roughness: _draw.default-main-levee-roughness, seed: _draw.default-main-levee-seed, ..style) = _drawing.draw-sketchy-circle(cetz.draw, center, radius, roughness: roughness, seed: seed, ..style)

/// Draw sketchy polygon (explicit main-levée)
#let ctz-sketchy-polygon(..vertices, roughness: _draw.default-main-levee-roughness, seed: _draw.default-main-levee-seed, close: true, stroke: black) = {
  let pts = vertices.pos()
  _drawing.draw-sketchy-polygon(cetz.draw, pts, roughness: roughness, seed: seed, close: close, stroke: stroke)
}

/// Draw sketchy ellipse (explicit main-levée)
#let ctz-sketchy-ellipse(center, rx, ry, angle: 0deg, roughness: _draw.default-main-levee-roughness, seed: _draw.default-main-levee-seed, ..style) = _drawing.draw-sketchy-ellipse(cetz.draw, center, rx, ry, angle: angle, roughness: roughness, seed: seed, ..style)

/// Draw sketchy rectangle (explicit main-levée)
#let ctz-sketchy-rect(corner1, corner2, roughness: _draw.default-main-levee-roughness, seed: _draw.default-main-levee-seed, ..style) = _drawing.draw-sketchy-rect(cetz.draw, corner1, corner2, roughness: roughness, seed: seed, ..style)

/// Draw sketchy arc (explicit main-levée)
#let ctz-sketchy-arc(center, radius, start-angle, end-angle, roughness: _draw.default-main-levee-roughness, seed: _draw.default-main-levee-seed, ..style) = _drawing.draw-sketchy-arc(cetz.draw, center, radius, start-angle, end-angle, roughness: roughness, seed: seed, ..style)

/// Resolve clip-canvas bounds from a tuple or dictionary
#let _resolve-clip-canvas-bounds(clip) = {
  if clip == none or clip == false { return none }
  if type(clip) == dictionary and (
    "xmin" in clip and "ymin" in clip and "xmax" in clip and "ymax" in clip
  ) {
    return (clip.xmin, clip.ymin, clip.xmax, clip.ymax)
  }
  if type(clip) == array and clip.len() == 4 {
    return (clip.at(0), clip.at(1), clip.at(2), clip.at(3))
  }
  if type(clip) == array and clip.len() == 2 and type(clip.at(0)) == array and type(clip.at(1)) == array {
    let a = clip.at(0)
    let b = clip.at(1)
    if a.len() >= 2 and b.len() >= 2 {
      return (a.at(0), a.at(1), b.at(0), b.at(1))
    }
  }
  panic("clip-canvas expects (xmin, ymin, xmax, ymax) or ((xmin, ymin), (xmax, ymax)) or dictionary with xmin/ymin/xmax/ymax; got " + repr(clip))
}

/// Normalize a canvas body to a flat array of element functions
#let _flatten-canvas-body(items) = {
  let out = ()
  for item in items {
    if type(item) == array {
      out += item
    } else if type(item) == function {
      out.push(item)
    } else if type(item) == content and item.has("children") {
      out += _flatten-canvas-body(item.children)
    }
  }
  out
}

/// CeTZ canvas wrapper with optional clip-to-canvas support
/// Usage: ctz-canvas(clip-canvas: (-1, -1, 4, 5), { ... })
#let ctz-canvas(
  length: 1cm,
  baseline: none,
  debug: false,
  background: none,
  stroke: none,
  padding: none,
  clip-canvas: auto,
  body,
) = {
  let clip-value = if clip-canvas == auto or clip-canvas == true {
    ctz-default-clip-canvas
  } else {
    clip-canvas
  }
  let clip-bounds = _resolve-clip-canvas-bounds(clip-value)

  let raw-body = if body == none {
    ()
  } else if type(body) == array {
    body
  } else if type(body) == content {
    body.children
  } else {
    (body,)
  }
  let body-array = _flatten-canvas-body(raw-body)

  let clip-body = if clip-bounds != none {
    let (xmin, ymin, xmax, ymax) = clip-bounds
    // Keep the canvas bounds aligned with the clip rect (hidden)
    (
      cetz.draw.hide(cetz.draw.rect((xmin, ymin), (xmax, ymax)), bounds: true) +
      _drawing.set-clip-region(cetz.draw, xmin, ymin, xmax, ymax)
    )
  } else { () }

  _canvas(
    length: length,
    baseline: baseline,
    debug: debug,
    background: background,
    stroke: stroke,
    padding: padding,
    clip-body + body-array,
  )
}

/// Initialize ctz-euclide (call at start of canvas body)
#let ctz-init() = _init()

/// Helper to convert point name to ctz: coordinate
#let ctz-pt(name) = _pt(name)

// Point definitions
#let ctz-def-points(..points) = _pts(..points)
#let ctz-pts(..points) = ctz-def-points(..points)
#let ctz-def-line(name, a, b) = _def-line-name(name, a, b)
#let ctz-def-circle(name, center, radius: auto, through: none) = _def-circle(name, center, radius: radius, through: through)
#let ctz-def-circle-diameter(name, a, b) = _def-circle-diameter(name, a, b)
#let ctz-def-circumcircle(name, a, b, c) = _def-circumcircle(name, a, b, c)
#let ctz-def-incircle(name, a, b, c) = _def-incircle(name, a, b, c)
#let ctz-def-excircle(name, a, b, c, vertex: "a") = _def-excircle(name, a, b, c, vertex: vertex)
#let ctz-def-euler-circle(name, a, b, c) = _def-euler-circle(name, a, b, c)
#let ctz-def-spieker-circle(name, a, b, c) = _def-spieker-circle(name, a, b, c)
#let ctz-def-apollonius-circle(name, a, b, k) = _def-apollonius-circle(name, a, b, k)
#let ctz-def-ellipse(name, center, rx, ry, angle: 0deg) = _def-ellipse(name, center, rx, ry, angle: angle)
#let ctz-def-parabola(name, focus, directrix, extent: auto, steps: 120) = _def-parabola(name, focus, directrix, extent: extent, steps: steps)
#let ctz-def-projectile(name, origin, velocity, gravity: 9.81, t-max: auto, steps: 80, y-floor: none, vectors: false, vector-count: 5, vector-scale: 0.12) = _def-projectile(name, origin, velocity, gravity: gravity, t-max: t-max, steps: steps, y-floor: y-floor, vectors: vectors, vector-count: vector-count, vector-scale: vector-scale)
#let ctz-def-parabola-focus(name, focus, p, angle: 0deg, extent: auto, steps: 120) = _def-parabola-focus(name, focus, p, angle: angle, extent: extent, steps: steps)
#let ctz-def-ellipse-foci(name1, name2, center, rx, ry, angle: 0deg) = _def-ellipse-foci(name1, name2, center, rx, ry, angle: angle)
#let ctz-def-ellipse-tangent(name, center, rx, ry, t, angle: 0deg, length: auto) = _def-ellipse-tangent(name, center, rx, ry, t, angle: angle, length: length)
#let ctz-def-ellipse-tangents-from(name1, name2, center, rx, ry, external, angle: 0deg, length: auto) = _def-ellipse-tangents-from(name1, name2, center, rx, ry, external, angle: angle, length: length)
#let ctz-def-parabola-tangent(name, focus, directrix, t, length: auto) = _def-parabola-tangent(name, focus, directrix, t, length: length)
#let ctz-def-parabola-tangents-from(name1, name2, focus, directrix, external, length: auto) = _def-parabola-tangents-from(name1, name2, focus, directrix, external, length: length)
#let ctz-def-polygon(name, ..points) = _def-polygon(name, ..points)

// Intersections
#let ctz-def-ll(name, l1, l2, ray: true) = _ll(name, l1, l2, ray: ray)
#let ctz-def-lc(result-names, line, circle-spec, near: none) = _lc(result-names, line, circle-spec, near: near)
#let ctz-def-cc(result-names, circle1, circle2) = _cc(result-names, circle1, circle2)

// Triangle centers
#let ctz-def-centroid(name, a, b, c) = _centroid(name, a, b, c)
#let ctz-def-circumcenter(name, a, b, c) = _circumcenter(name, a, b, c)
#let ctz-def-incenter(name, a, b, c) = _incenter(name, a, b, c)
#let ctz-def-orthocenter(name, a, b, c) = _orthocenter(name, a, b, c)
#let ctz-def-euler(name, a, b, c) = _euler(name, a, b, c)
#let ctz-def-lemoine(name, a, b, c) = _lemoine(name, a, b, c)
#let ctz-def-nagel(name, a, b, c) = _nagel(name, a, b, c)
#let ctz-def-gergonne(name, a, b, c) = _gergonne(name, a, b, c)
#let ctz-def-spieker(name, a, b, c) = _spieker(name, a, b, c)
#let ctz-def-feuerbach(name, a, b, c) = _feuerbach(name, a, b, c)
#let ctz-def-mittenpunkt(name, a, b, c) = _mittenpunkt(name, a, b, c)
#let ctz-def-excenter(name, a, b, c, vertex: "A") = _excenter(name, a, b, c, vertex: vertex)

/// A triangle centre, named by which centre it is rather than by its own
/// function. Reads closer to tkz-euclide, and keeps the triangle in one place:
///
///   ctz-def-triangle-center("in", "I", "A,B,C")     // incenter
///   ctz-def-triangle-center("centroid", "G", "A,B,C")
///   ctz-def-triangle-center("ex", "J", "A,B,C", vertex: "B")
///
/// The vertices may be written as one comma-separated string, as an array, or
/// as three arguments; the eleven ctz-def-<centre> functions keep working
/// unchanged.
///
/// Kinds: "centroid"/"median"/"g", "circum"/"circumcenter"/"o",
/// "in"/"incenter"/"i", "ortho"/"orthocenter"/"h", "euler"/"nine-point"/"n",
/// "lemoine"/"symmedian"/"k", "nagel", "gergonne", "spieker", "feuerbach",
/// "mittenpunkt", "ex"/"excenter" (with vertex:).
#let ctz-def-triangle-center(kind, name, ..vertices, vertex: "A") = {
  let vs = vertices.pos()
  // "A,B,C" or ("A", "B", "C") or "A", "B", "C"
  if vs.len() == 1 and type(vs.at(0)) == str and vs.at(0).contains(",") {
    vs = vs.at(0).split(",").map(v => v.trim())
  } else if vs.len() == 1 and type(vs.at(0)) == array {
    vs = vs.at(0)
  }
  assert(
    vs.len() == 3,
    message: "ctz-def-triangle-center: expected three vertices, got " + repr(vs),
  )
  let (a, b, c) = vs
  let k = lower(kind)
  if k in ("centroid", "median", "g") { _centroid(name, a, b, c) }
  else if k in ("circum", "circumcenter", "circumcentre", "o") { _circumcenter(name, a, b, c) }
  else if k in ("in", "incenter", "incentre", "i") { _incenter(name, a, b, c) }
  else if k in ("ortho", "orthocenter", "orthocentre", "h") { _orthocenter(name, a, b, c) }
  else if k in ("euler", "nine-point", "ninepoint", "n") { _euler(name, a, b, c) }
  else if k in ("lemoine", "symmedian", "k") { _lemoine(name, a, b, c) }
  else if k == "nagel" { _nagel(name, a, b, c) }
  else if k == "gergonne" { _gergonne(name, a, b, c) }
  else if k == "spieker" { _spieker(name, a, b, c) }
  else if k == "feuerbach" { _feuerbach(name, a, b, c) }
  else if k == "mittenpunkt" { _mittenpunkt(name, a, b, c) }
  else if k in ("ex", "excenter", "excentre") { _excenter(name, a, b, c, vertex: vertex) }
  else {
    panic("ctz-def-triangle-center: unknown centre " + repr(kind)
      + ". Known: centroid, circum, in, ortho, euler, lemoine, nagel, gergonne, "
      + "spieker, feuerbach, mittenpunkt, ex")
  }
}

// Special triangles
#let ctz-def-medial-triangle(name-a, name-b, name-c, a, b, c) = _medial(name-a, name-b, name-c, a, b, c)
#let ctz-def-orthic-triangle(name-a, name-b, name-c, a, b, c) = _orthic(name-a, name-b, name-c, a, b, c)
#let ctz-def-intouch-triangle(name-a, name-b, name-c, a, b, c) = _intouch(name-a, name-b, name-c, a, b, c)
#let ctz-def-thales-triangle(name-a, name-b, name-c, center, radius, base-angle: 0, orientation: "left") = _thales-triangle(name-a, name-b, name-c, center, radius, base-angle: base-angle, orientation: orientation)

// Point constructions
#let ctz-def-midpoint(name, a, b) = _midpoint(name, a, b)
#let ctz-def-equilateral(name, a, b) = _equilateral(name, a, b)
#let ctz-def-square(name-c, name-d, a, b) = _square(name-c, name-d, a, b)
#let ctz-def-golden(name, a, b, inside: true) = _golden(name, a, b, inside: inside)
#let ctz-def-barycentric(name, a, b, c, x, y, z) = _barycentric(name, a, b, c, x, y, z)
#let ctz-def-point-on-circle(name, center, radius, angle-deg) = _point-on-circle(name, center, radius, angle-deg)
#let ctz-def-regular-polygon(..args) = _regular-polygon(..args)
#let ctz-def-linear(name, a, b, k) = _linear(name, a, b, k)
#let ctz-def-symmetry(name, source, center) = _symmetry(name, source, center)
#let ctz-def-inversion(name, source, center, radius) = _inversion(name, source, center, radius)
#let ctz-def-tangent-from(name1, name2, point, center, radius) = _tangent-from(name1, name2, point, center, radius)
#let ctz-def-tangent-at(name1, name2, point-on-circle, center) = _tangent-at(name1, name2, point-on-circle, center)
#let ctz-def-radical-axis(name1, name2, circle1, circle2) = _radical-axis(name1, name2, circle1, circle2)

// Transformations
#let ctz-def-rotation(name, source, center, angle-deg) = _rotation(name, source, center, angle-deg)
#let ctz-def-reflect(name, source, p1, p2) = _reflect(name, source, p1, p2)
#let ctz-def-translate(name, source, vector) = _translate(name, source, vector)
#let ctz-def-homothety(name, source, center, k) = _homothety(name, source, center, k)
#let ctz-def-project(name, source, p1, p2) = _project(name, source, p1, p2)
#let ctz-duplicate(target-name, source-name, points: auto) = _duplicate(target-name, source-name, points: points)

// Line construction helpers
#let ctz-def-perp(name1, name2, line, through) = _perp(name1, name2, line, through)
#let ctz-def-para(name1, name2, line, through) = _para(name1, name2, line, through)
#let ctz-def-bisect(name1, name2, a, vertex, c) = _bisect(name1, name2, a, vertex, c)
#let ctz-def-mediator(name1, name2, a, b) = _mediator(name1, name2, a, b)

// Drawing functions
#let ctz-style(..style-args) = _style(..style-args)

/// Enable/disable/configure automatic label collision avoidance globally.
/// - ctz-label-avoid(false)          — turn it off (labels go exactly where asked)
/// - ctz-label-avoid(true)           — turn it back on with defaults
/// - ctz-label-avoid((rings: 5, shrink: ()))  — tweak the engine
/// Per-label override: labels: (A: (pos: "above", avoid: false))
#let ctz-label-avoid(setting) = _style(label: (avoid: setting))
#let ctz-draw(..args) = _polymorphic-draw(..args)
#let ctz-draw-line(..args) = _draw-line(..args)
#let ctz-draw-points(..names) = _points(..names)
#let ctz-points(..names) = ctz-draw-points(..names)
#let ctz-draw-labels(..args) = _labels(..args)
#let ctz-draw-angle(vertex, a, b, ..opts) = _angle(vertex, a, b, ..opts)
#let ctz-draw-polygon(..args) = _polygon(..args)
#let ctz-draw-fill-polygon(..args) = _fill-polygon(..args)
#let ctz-draw-regular-polygon(names, ..opts) = _draw-regular-polygon(names, ..opts)
#let ctz-draw-fill-regular-polygon(names, ..opts) = _fill-regular-polygon(names, ..opts)
#let ctz-draw-path(spec, ..opts) = _path(spec, ..opts)
#let ctz-draw-segment(a, b, ..opts) = _segment(a, b, ..opts)
#let ctz-draw-measure-segment(a, b, ..opts) = _measure-segment(a, b, ..opts)
#let ctz-draw-line-add(a, b, ..opts) = _line-add(a, b, ..opts)
#let ctz-draw-arc(center, start, end, ..opts) = _arc(center, start, end, ..opts)
#let ctz-draw-arc-r(center, radius, start-angle, end-angle, ..opts) = _arc-r(center, radius, start-angle, end-angle, ..opts)
#let ctz-draw-circle-r(center, radius, ..opts) = _circle-r(center, radius, ..opts)
#let ctz-draw-circle-through(center, through, ..opts) = _circle-through(center, through, ..opts)
#let ctz-draw-circle-diameter(a, b, ..opts) = _circle-diameter(a, b, ..opts)
#let ctz-draw-circle(name, ..opts) = _draw-circle(name, ..opts)
#let ctz-draw-ellipse(center, rx, ry, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let c = _resolve-point(ctx, center)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    _drawing.draw-ellipse(cetz.draw, c, rx-num, ry-num, ..opts)
  })
}
#let ctz-draw-parabola(focus, directrix, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let f = _resolve-point(ctx, focus)
    let (a, b) = _parse-line(ctx, directrix)
    _drawing.draw-parabola-focus-directrix(cetz.draw, f, a, b, ..opts)
  })
}
#let ctz-draw-parabola-focus(focus, p, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let f = _resolve-point(ctx, focus)
    let p-num = if type(p) == length { p / 1cm } else { p }
    _drawing.draw-parabola-focus(cetz.draw, f, p-num, ..opts)
  })
}
#let ctz-draw-ellipse-tangent(center, rx, ry, t, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let c = _resolve-point(ctx, center)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    _drawing.draw-ellipse-tangent(cetz.draw, c, rx-num, ry-num, t, ..opts)
  })
}
#let ctz-ellipse-project-point(center, rx, ry, point, angle: 0deg) = {
  cetz.draw.get-ctx(ctx => {
    let c = _resolve-point(ctx, center)
    let p = _resolve-point(ctx, point)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    _conic.ellipse-project-point-raw(c, rx-num, ry-num, angle: angle, p)
  })
}
#let ctz-ellipse-tangents-from-point(center, rx, ry, point, angle: 0deg, length: auto) = {
  cetz.draw.get-ctx(ctx => {
    let c = _resolve-point(ctx, center)
    let p = _resolve-point(ctx, point)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let len-num = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    _conic.ellipse-tangents-from-point-raw(c, rx-num, ry-num, angle: angle, p, length: len-num)
  })
}
#let ctz-ellipse-tangent-from-point-towards(center, rx, ry, point, target, angle: 0deg, length: auto) = {
  cetz.draw.get-ctx(ctx => {
    let c = _resolve-point(ctx, center)
    let p = _resolve-point(ctx, point)
    let t = _resolve-point(ctx, target)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let len-num = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    _conic.ellipse-tangent-from-point-towards-raw(c, rx-num, ry-num, angle: angle, p, t, length: len-num)
  })
}
#let ctz-draw-ellipse-tangent-from-point-towards(center, rx, ry, point, target, angle: 0deg, length: auto, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let c = _resolve-point(ctx, center)
    let p = _resolve-point(ctx, point)
    let t = _resolve-point(ctx, target)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let len-num = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    let res = _conic.ellipse-tangent-from-point-towards-raw(c, rx-num, ry-num, angle: angle, p, t, length: len-num)
    if res != none {
      let p1 = res.at(0)
      let p2 = res.at(1)
      cetz.draw.line(p1, p2, ..opts)
    }
  })
}

/// Define a point by projecting onto an ellipse (ray from center through point)
#let ctz-def-ellipse-project(name, center, rx, ry, point, angle: 0deg) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let p = _resolve-point(ctx, point)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let result = _conic.ellipse-project-point-raw(c, rx-num, ry-num, angle: angle, p)
    let points = _get-points(ctx)
    points.insert(name, result)
    ctx = _set-points(ctx, points)
    (ctx: ctx)
  },)
}

/// Define a tangent line to ellipse from external point, choosing contact closest to target
#let ctz-def-ellipse-tangent-from(name1, name2, center, rx, ry, point, target, angle: 0deg, length: auto) = {
  (ctx => {
    let c = _resolve-point(ctx, center)
    let p = _resolve-point(ctx, point)
    let t = _resolve-point(ctx, target)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let len-num = if length == auto { auto } else if type(length) == length { length / 1cm } else { length }
    let res = _conic.ellipse-tangent-from-point-towards-raw(c, rx-num, ry-num, angle: angle, p, t, length: len-num)
    if res != none {
      let points = _get-points(ctx)
      points.insert(name1, res.at(0))
      points.insert(name2, res.at(1))
      ctx = _set-points(ctx, points)
    }
    (ctx: ctx)
  },)
}
#let ctz-ellipse-circle-intersections(center, rx, ry, circle-center, r, angle: 0deg, steps: 360) = {
  cetz.draw.get-ctx(ctx => {
    let c = _resolve-point(ctx, center)
    let cc = _resolve-point(ctx, circle-center)
    let rx-num = if type(rx) == length { rx / 1cm } else { rx }
    let ry-num = if type(ry) == length { ry / 1cm } else { ry }
    let r-num = if type(r) == length { r / 1cm } else { r }
    _conic.ellipse-circle-intersections-raw(c, rx-num, ry-num, angle: angle, cc, r: r-num, steps: steps)
  })
}

/// High-level construction: ellipse and circles tangency (geometry only)
/// Returns a dictionary of key points and lines for the construction.
#let ctz-ellipse-tangency-geom(a, b) = {
  let unit = v => {
    let len = calc.sqrt(v.at(0) * v.at(0) + v.at(1) * v.at(1))
    if len < 1e-9 { (0, 0) } else { (v.at(0) / len, v.at(1) / len) }
  }

  let O = (0, 0)
  let H = (a / 2, 0)
  let Hp = (0, -b / 2)

  let M = (a / 2, calc.sqrt(a * a - (a / 2) * (a / 2)))
  let N = (-calc.sqrt(b * b - (b / 2) * (b / 2)), -b / 2)

  let Mp = ctz-ellipse-project-point(O, b, a, M)
  let Np = ctz-ellipse-project-point(O, b, a, N)

  let tM = unit((-M.at(1), M.at(0)))
  let tN = unit((-N.at(1), N.at(0)))

  let TM1 = (M.at(0) - 4 * tM.at(0), M.at(1) - 4 * tM.at(1))
  let TM2 = (M.at(0) + 4 * tM.at(0), M.at(1) + 4 * tM.at(1))
  let TN1 = (N.at(0) - 4 * tN.at(0), N.at(1) - 4 * tN.at(1))
  let TN2 = (N.at(0) + 4 * tN.at(0), N.at(1) + 4 * tN.at(1))

  // Tangent intersections with axes
  let t = -M.at(1) / tM.at(1)
  let P = (M.at(0) + t * tM.at(0), 0)
  let tp = -N.at(0) / tN.at(0)
  let Pp = (0, N.at(1) + tp * tN.at(1))

  let tP = ctz-ellipse-tangent-from-point-towards(O, b, a, P, Mp)
  let tPp = ctz-ellipse-tangent-from-point-towards(O, b, a, Pp, Np)

  (
    O: O, H: H, Hp: Hp, M: M, N: N, Mp: Mp, Np: Np, P: P, Pp: Pp,
    TM1: TM1, TM2: TM2, TN1: TN1, TN2: TN2,
    tP: tP, tPp: tPp,
  )
}

/// Draw the full ellipse/circles tangency construction (matches the manual example)
#let ctz-draw-ellipse-tangency(a, b, labels: true) = {
  let g = ctz-ellipse-tangency-geom(a, b)
  let O = g.O
  let H = g.H
  let Hp = g.Hp
  let M = g.M
  let N = g.N
  let Mp = g.Mp
  let Np = g.Np
  let P = g.P
  let Pp = g.Pp
  let TM1 = g.TM1
  let TM2 = g.TM2
  let TN1 = g.TN1
  let TN2 = g.TN2

  let blue-stroke = (paint: blue, thickness: 0.8pt)
  let green-stroke = (paint: green, thickness: 0.8pt)
  let red-stroke = (paint: red, thickness: 0.8pt)

  ctz-draw(line: ((-5, 0), (5, 0)), stroke: (paint: black, thickness: 0.6pt))
  ctz-draw(line: ((0, -5), (0, 5)), stroke: (paint: black, thickness: 0.6pt))

  ctz-draw(circle-r: (O, a), stroke: blue-stroke)
  ctz-draw(circle-r: (O, b), stroke: green-stroke)
  ctz-draw(ellipse: (O, b, a, 0deg), stroke: red-stroke)

  ctz-draw(line: (H, M), stroke: (paint: black, thickness: 0.6pt, dash: "dashed"))
  ctz-draw(line: (Hp, Np), stroke: (paint: black, thickness: 0.6pt, dash: "dashed"))
  ctz-draw(line: (O, M), stroke: blue-stroke)
  ctz-draw(line: (O, N), stroke: green-stroke)

  ctz-draw(line: (TM1, TM2), stroke: blue-stroke)
  ctz-draw(line: (TN1, TN2), stroke: green-stroke)

  ctz-def-points(O: O, H: H, Hp: Hp, M: M, N: N, TM1: TM1, TN1: TN1)
  ctz-draw-mark-right-angle("TM1", "M", "O", color: blue)
  ctz-draw-mark-right-angle("TN1", "N", "O", color: green)

  if g.tP != none {
    let A1 = g.tP.at(0)
    let A2 = g.tP.at(1)
    ctz-draw(line: (A1, A2), stroke: red-stroke, mark: (end: ">", start: ">"))
  }
  if g.tPp != none {
    let B1 = g.tPp.at(0)
    let B2 = g.tPp.at(1)
    ctz-draw(line: (B1, B2), stroke: red-stroke, mark: (end: ">", start: ">"))
  }

  if labels {
    ctz-def-points(Mp: Mp, Np: Np, P: P, Pp: Pp)
    ctz-draw(points: ("O", "H", "Hp", "M", "Mp", "N", "Np", "P", "Pp"), labels: (
      O: (pos: "below left", offset: (-0.15, -0.15)),
      H: "below", Hp: "left", M: "above right", Mp: "above",
      N: "left", Np: "below left", P: "right", Pp: "below"
    ))
  }
}
#let ctz-draw-parabola-tangent(focus, directrix, t, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let f = _resolve-point(ctx, focus)
    let (a, b) = _parse-line(ctx, directrix)
    _drawing.draw-parabola-tangent(cetz.draw, f, a, b, t, ..opts)
  })
}
#let ctz-draw-parabola-tangents-from-point(focus, directrix, external, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let f = _resolve-point(ctx, focus)
    let (a, b) = _parse-line(ctx, directrix)
    let p = _resolve-point(ctx, external)
    _drawing.draw-parabola-tangents-from-point(cetz.draw, f, a, b, p, ..opts)
  })
}
#let ctz-draw-projectile(origin, velocity, ..opts) = {
  cetz.draw.get-ctx(ctx => {
    let o = _resolve-point(ctx, origin)
    let v = _resolve-vector(ctx, velocity)
    _drawing.draw-projectile(cetz.draw, o, v, ..opts)
  })
}

#let ctz-draw-circumcircle(a, b, c, ..opts) = _circumcircle(a, b, c, ..opts)
#let ctz-draw-incircle(a, b, c, ..opts) = _incircle(a, b, c, ..opts)
#let ctz-draw-semicircle(a, b, ..opts) = _semicircle(a, b, ..opts)
#let ctz-draw-sector(center, start, end, ..opts) = _sector(center, start, end, ..opts)
#let ctz-draw-mark-segment(a, b, ..opts) = _mark-segment(a, b, ..opts)
#let ctz-draw-mark-right-angle(a, vertex, c, ..opts) = _mark-right-angle(a, vertex, c, ..opts)
#let ctz-draw-fill-angle(vertex, a, c, ..opts) = _fill-angle(vertex, a, c, ..opts)
#let ctz-draw-label-segment(a, b, ..opts) = _label-segment(a, b, ..opts)
#let ctz-draw-label-angle(vertex, a, c, ..opts) = _label-angle(vertex, a, c, ..opts)
#let ctz-label-circle(name, label, pos: "above", dist: 0.2, offset: (0, 0)) = _label-circle(name, label, pos: pos, dist: dist, offset: offset)
#let ctz-label-polygon(name, label, pos: "center", dist: 0.2, offset: (0, 0)) = _label-polygon(name, label, pos: pos, dist: dist, offset: offset)

// Calculations (return values via context)
#let ctz-calc-length(a, b) = _calc-length(a, b)
#let ctz-calc-angle(a, b, c) = _calc-angle(a, b, c)
#let ctz-calc-area(a, b, c) = _calc-area(a, b, c)
#let ctz-calc-slope(a, b) = _calc-slope(a, b)
#let ctz-calc-ratio(a, b, c) = _calc-ratio(a, b, c)

// Grid and axes
#let ctz-draw-grid(..opts) = _grid(..opts)
#let ctz-draw-axes(..opts) = _axes(..opts)
#let ctz-draw-axis-x(..opts) = _axis-x(..opts)
#let ctz-draw-axis-y(..opts) = _axis-y(..opts)
#let ctz-draw-hline(y, ..opts) = _hline(y, ..opts)
#let ctz-draw-vline(x, ..opts) = _vline(x, ..opts)
#let ctz-draw-text(x, y, content, ..opts) = _draw-text(x, y, content, ..opts)

// Clipping
#let ctz-set-clip(xmin, ymin, xmax, ymax) = _set-clip(xmin, ymin, xmax, ymax)
#let ctz-clear-clip() = _clear-clip()
#let ctz-show-clip(stroke: gray + 0.5pt) = _show-clip(stroke: stroke)
#let ctz-draw-line-global-clip(a, b, add: (10, 10), stroke: black) = _ctz-line(a, b, add: add, stroke: stroke)
#let ctz-draw-seg-global-clip(a, b, stroke: black) = _seg(a, b, stroke: stroke)
#let ctz-draw-clipped-line(p1, p2, xmin, ymin, xmax, ymax, stroke: black) = _clipped-line(p1, p2, xmin, ymin, xmax, ymax, stroke: stroke)
#let ctz-draw-clipped-line-add(a, b, xmin, ymin, xmax, ymax, add: (10, 10), stroke: black) = _clipped-line-add(a, b, xmin, ymin, xmax, ymax, add: add, stroke: stroke)
#let ctz-draw-clip-boundary(xmin, ymin, xmax, ymax, stroke: black + 0.5pt) = _clip-boundary(xmin, ymin, xmax, ymax, stroke: stroke)
#let ctz-clip-line-to-rect = _clip-line-to-rect

// Raw algorithms (no context needed)
#let ctz-algorithms = _algorithms

// Utility re-exports
#let ctz-midpoint-raw = _midpoint-raw
#let ctz-dist = _dist
#let ctz-angle-to = _angle-to
#let ctz-project-point-on-line = _project-point-on-line

#let ctz-rotate-point = _rotate-point

// Export raw conic functions for advanced usage in documentation/examples
#let ellipse-foci-raw = _conic.ellipse-foci-raw
#let ellipse-angpoint-raw = _conic.ellipse-angpoint-raw  
#let ellipse-point-raw = _conic.ellipse-point-raw
#let ellipse-points-raw = _conic.ellipse-points-raw
#let ellipse-tangents-from-point-raw = _conic.ellipse-tangents-from-point-raw
#let parabola-directrix-raw = _conic.parabola-directrix-raw
#let parabola-tangents-from-point-raw = _conic.parabola-tangents-from-point-raw
#let parabola-point-raw = _conic.parabola-point-raw
#let parabola-tangent-raw = _conic.parabola-tangent-raw

// Export drawing helper functions for grid/annotation examples
#let triangular-pos = _drawing.triangular-pos
#let pascal-pos = _drawing.pascal-pos
#let grid-pos = _drawing.grid-pos
#let hex-pos = _drawing.hex-pos
#let binomial = _drawing.binomial
#let draw-triangular-grid = _drawing.draw-triangular-grid
#let draw-rectangular-grid = _drawing.draw-rectangular-grid
#let draw-pascal-values = _drawing.draw-pascal-values
#let draw-row-labels = _drawing.draw-row-labels
#let draw-diagonal-labels = _drawing.draw-diagonal-labels
#let highlight-fill = _drawing.highlight-fill
#let highlight-outline = _drawing.highlight-outline
#let highlight-many = _drawing.highlight-many
#let curved-arrow = _drawing.curved-arrow
#let smooth-arrow = _drawing.smooth-arrow
#let draw-addition-indicator = _drawing.draw-addition-indicator
#let draw-brace-h = _drawing.draw-brace-h
#let draw-brace-v = _drawing.draw-brace-v
